<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>ICEA | El Mesón</title>

    <!-- Para mostrar la ruta estática -->
    <?php
        $url = Rutas::mdlRuta(); 
        $urlImg = Rutas::mdlRutaImg();
    ?>

    <!-- Favicon -->
    <!-- <link href="vistas/assets/img/favicon.ico" rel="icon"> -->

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"> -->
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300;700&family=Work+Sans:wght@400;600&display=swap"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css"/>

    <!-- ===================================================== -->

    <link rel="stylesheet" href="<?php echo $url; ?>vistas/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>vistas/assets/lib/owl-carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>vistas/assets/css/animate.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>vistas/assets/lib/swiper/swiper-bundle.min.css">

    <link href="<?php echo $url; ?>vistas/css/conocenos.css" rel="stylesheet">
    <link href="<?php echo $url; ?>vistas/css/eventos.css" rel="stylesheet">
    <link href="<?php echo $url; ?>vistas/css/learning.css" rel="stylesheet">
    <link href="<?php echo $url; ?>vistas/css/tienda.css" rel="stylesheet">
    <link href="<?php echo $url; ?>vistas/css/misiones.css" rel="stylesheet">
    <link href="<?php echo $url; ?>vistas/css/recursos.css" rel="stylesheet">

</head>
<body>

        <?php

            if(isset($_GET["ruta"])){
              $ruta = explode("/", $_GET["ruta"]);
              /* var_dump($ruta); */
            } else {
              $ruta = "";
            }

            include "modulos/navbar.php";

            if($ruta == ""){              
              include "modulos/conocenos.php";
            } else if($ruta[0] == "conocenos" ||
                      $ruta[0] == "eventos" || 
                      $ruta[0] == "recursos" ||
                      $ruta[0] == "tienda" ||
                      $ruta[0] == "misiones" ||
                      $ruta[0] == "ebd" ||
                      $ruta[0] == "adolescentes" ||
                      $ruta[0] == "jovenes" ||
                      $ruta[0] == "dorcas" ||
                      $ruta[0] == "alabanza" ||
                      $ruta[0] == "danza" ||
                      $ruta[0] == "voluntariado" ||
                      $ruta[0] == "rehabilitacion" ||
                      $ruta[0] == "social" ||
                      $ruta[0] == "learning"){
              include "modulos/".$ruta[0].".php";
            } 

            include "modulos/footer.php";

        ?>



    <!-- ======================================================================================= -->

    <!-- Librerías JS -->
    <script src="<?php echo $url; ?>vistas/assets/js/jquery-3.7.1.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/js/easing.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/js/typed.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/lib/swiper/swiper-bundle.min.js"></script>
    
    <!-- Detectar scroll para animaciones -->
    <script src="<?php echo $url; ?>vistas/assets/js/wow.min.js"></script>

    <!-- Galería -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>

    <!-- JS personalizado -->
     <script src="<?php echo $url; ?>vistas/js/conocenos.js"></script>
     <script src="<?php echo $url; ?>vistas/js/eventos.js"></script>
     <script src="<?php echo $url; ?>vistas/js/recursos.js"></script>

     <script>
      new WOW().init();
     </script>

    
    
</body>
</html>