<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Acción social</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-12 container">
            <p class="display-6 fw-bold text-center mb-0">Visualiza el impacto de nuestras</p>
            <p class="display-6 fw-bold text-center"><span class="text-color-primary">acciones solidarias</span></p>

            <p class="fs-3 text-center"> Desde la entrega de juguetes a niños en situación de vulnerabilidad hasta visitas de acompañamiento hospitalario.</p>

            <p class="fs-3 mb-3 mt-3 text-center">Somos una entidad activa que trabaja por el bienestar de nuestra comunidad local.</p>

            <div class="img-social text-center">
                <img src="<?php echo $url; ?>vistas/assets/img/social-1.svg" alt="">
            </div>
            
        </div>
    </div>

</div>