<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Misiones</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-12">
            <p class="text-color-success fw-bold">Hechos 1:8</p>
            <p class="display-6 fw-bold">Pero recibiréis poder, cuando haya venido sobre vosotros el Espíritu Santo, y me seréis testigos en Jerusalén, en toda Judea, en Samaria, y hasta lo último de la tierra.</p>
            <p class="fs-5">Damos pasos firmes en la expansión del Reino, comprometidos con la Gran Comisión. Actualmente, apoyamos activamente la obra misionera de ICEA en </p>
            <div class="">
                <span class="fs-5 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> Ecuador</span>
                <span class="fs-5 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> Colombia</span>
                <span class="fs-5 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> Paraguay</span>
                <span class="fs-5 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> India</span>
                <span class="fs-5 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> España</span>
            </div>

            <p class="fs-5 mb-3 mt-3">y organizamos viajes misioneros para llevar el amor de Dios de forma presencial (como nuestro viaje misionero: MISSION TRIP TARIFA)</p>

            <div class="img-misiones">
                <img class="img-flyer" src="<?php echo $url; ?>vistas/assets/img/flyer-tarifa.jpg" alt="Flyer de viaje misionero">
                <span class="badge text-bg-dark mx-3">Entrenamiento misionero 2026</span>
            </div>
            
        </div>
    </div>

</div>