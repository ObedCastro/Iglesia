<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Voluntariado</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-12">
            <div class="texto">
                <p class="display-6 fw-bold">Únete a nuestro programa de voluntariado en un entorno natural privilegiado.</p>
    
                <p class="fs-5">Buscamos personas comprometidas con el bienestar social, dispuestas a aportar su tiempo y habilidades para el mantenimiento de nuestras instalaciones y el apoyo en actividades de reinserción.</p>
    
            </div>
            
            <div class="imagen" style="justify-self: center;">
                <img src="<?php echo $url; ?>vistas/assets/img/voluntariado.svg" alt="" style="width: 600px;">
            </div>

            <p class="fs-2 mb-5 mt-3 fw-bold text-center">Tu ayuda construye <span class="text-color-primary">oportunidades.</span></p>

            <p class="text-center">Ubícanos en <i class="fa fa-arrow-down"></i></p>
            <div class="map-voluntariado p-1 d-flex mb-5" style="border-radius: 10px; text-align: center; background: lightgray;">
                <iframe style="border-radius: 10px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d388702.46351394657!2d-4.303477990128753!3d40.436800128806354!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422997800a3c81%3A0xc436dec1618c2269!2zTWFkcmlkLCBFc3Bhw7Fh!5e0!3m2!1ses!2ssv!4v1768492416946!5m2!1ses!2ssv" width="100%" height="300px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            
        </div>
    </div>

</div>