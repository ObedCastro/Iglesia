<div class="container-fluid learning"></div>

<div class="row pt-2">
    <nav aria-label="breadcrumb mb-0">
        <ol class="breadcrumb mb-0 px-3">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Eventos</li>
            <hr>
        </ol>
    </nav>
    
    <div class="underline-tabs mb-5">
        <ul class="nav nav-tabs" id="underlineTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab2" data-bs-toggle="tab" data-bs-target="#memorias" type="button" role="tab">
                    <span class="fs-5">Memorias El Mesón</span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="profile-tab2" data-bs-toggle="tab" data-bs-target="#calendario" type="button" role="tab">
                    <span class="fs-5">Calendario El Mesón</span>
                </button>
            </li>
        </ul>

        <div class="tab-content my-4" id="underlineTabsContent">
            <div class="tab-pane fade show active" id="memorias" role="tabpanel">
                <div class="imagenes">
                    <section class="portfolio pt-0" id="portfolio">
                        <div class="row">

                            <p class="fs-4 fw-bold text-center mb-0">Eventos realizados</p>
                            <p class="display-3 fw-bold text-center"><span class="titulo-evento">Evento de navidad</span></p>
                            <p class="fs-6 text-center mb-0">Celebramos el nacimiento de Jesús con gozo y comunidad.</p>
                            <p class="fs-6 text-center">Un tiempo especial donde compartimos el mensaje de esperanza, regalos y la unidad de la familia de la fe.</p>

                            <hr>

                            <div class="container text-center">
                                <button class="filter-button" data-filter="all">Todo</button>
                                <button class="filter-button" data-filter="category1">Categoría 1</button>
                                <button class="filter-button" data-filter="category2">Categoría 2</button>
                                <button class="filter-button" data-filter="category3">Categoría 3</button>
                            </div>
                            
                            <br/>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category1">
                                <a class="fancybox" rel="ligthbox" href="<?php echo $url; ?>vistas/assets/img/carousel-1.jpg">
                                    <img class="img-responsive" alt="" src="<?php echo $url; ?>vistas/assets/img/carousel-1.jpg" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 1</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category2">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=526">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=526" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 2</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category3">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=626">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=626" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 3</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category1">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=626">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=626" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 4</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category2">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=486">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=486" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 5</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category3">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=846">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=846" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 6</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category1">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=1066">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=1066" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 7</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category2">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=506">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=506" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 8</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category3">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=1026">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=1026" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 9</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category1">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=1077">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=1077" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 10</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category2">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=102">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=102" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 11</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                            <div class="gallery_product col-sm-3 col-xs-6 filter category3">
                                <a class="fancybox" rel="ligthbox" href="https://picsum.photos/400/250?image=106">
                                    <img class="img-responsive" alt="" src="https://picsum.photos/400/250?image=106" />
                                    <div class='img-info'>
                                        <p class="fs-4 mb-0 fw-bold">Image Title 12</p class="fs-4 mb-0 fw-bold">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </a>
                            </div>

                        </div>
                    </section>
                </div>
            </div>
            <div class="tab-pane fade" id="calendario" role="tabpanel">
                <p class="display-3 fw-bold text-center"><span class="titulo-evento">Próximos eventos</span></p>

            </div>
        </div>
    </div>

</div>
