<div class="container-fluid learning"></div>

<div class="row pt-2">
    <nav aria-label="breadcrumb mb-0">
        <ol class="breadcrumb mb-0 px-3">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Eventos</li>
            <hr>
        </ol>
    </nav>
    
    <div class="underline-tabs mb-5">
        <ul class="nav nav-tabs" id="underlineTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab2" data-bs-toggle="tab" data-bs-target="#memorias" type="button" role="tab">
                    <span class="fs-5">Memorias El Mesón</span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="profile-tab2" data-bs-toggle="tab" data-bs-target="#calendario" type="button" role="tab">
                    <span class="fs-5">Calendario El Mesón</span>
                </button>
            </li>
        </ul>

        <div class="tab-content my-4" id="underlineTabsContent">
            <div class="tab-pane fade show active" id="memorias" role="tabpanel">
                <div class="imagenes">
                    <section class="portfolio pt-0" id="portfolio">
                        <p class="fs-3 fw-bold text-center mb-0">Eventos realizados</p>

                        <div class="row evento">
                            <p class="display-2 fw-bold text-center"><span class="titulo-evento">Evento de navidad</span></p>
                            <p class="fs-5 text-center mb-0">Celebramos el nacimiento de Jesús con gozo y comunidad.</p>
                            <p class="fs-5 text-center">Un tiempo especial donde compartimos el mensaje de esperanza, regalos y la unidad de la familia de la fe.</p>

                            <hr>


                            <div class="container text-center">
                                <?php 
                                    $eventos = ControladorEventos::ctrMostrarEventos(null, null);
                                ?>

                                <br>
                                <button class="filter-button fs-5" data-filter="all">Todo</button>

                                <?php foreach ($eventos as $evento): ?>
                                    <button class="filter-button fs-5" data-filter="<?= $evento["id"]; ?>"><?= $evento["titulo"] ?></button>
                                <?php endforeach; ?>
                            </div>
                            
                            <br/>

                            <div class="galeria_eventos">

                            <?php
                                $imagenes = [];

                                foreach ($eventos as $evento) {
                                    foreach ($evento["galeria"] as $img) {
                                        $imagenes[] = [
                                            "evento_id" => $evento["id"],
                                            "imagen" => $img["imagen"],
                                            "titulo" => $img["titulo"] ?? "",
                                            "descripcion" => $img["descripcion"] ?? ""
                                        ];
                                    }
                                }

                                shuffle($imagenes); // 👈 aquí se mezclan
                                ?>


                                <?php foreach ($imagenes as $img): ?>
                                        <div class="gallery_product col-sm-3 col-xs-6 filter <?= $img["evento_id"]; ?>">
                                            <a class="fancybox" rel="ligthbox" href="<?= $urlImg; ?>vistas/assets/img/eventos/<?= $img["imagen"] ?>">
                                                <img loading="lazy" class="img-responsive" alt="" src="<?= $urlImg; ?>vistas/assets/img/eventos/<?= $img["imagen"] ?>" />
                                                <div class='img-info'>
                                                    <p class="fs-4 mb-0 fw-bold"><?= $img["titulo"]; ?></p class="fs-4 mb-0 fw-bold">
                                                    <p><?= $img["descripcion"]; ?></p>
                                                </div>
                                            </a>
                                        </div>
                                <?php endforeach; ?>
                            </div>


                        </div>
                    </section>
                </div>
            </div>
            <div class="tab-pane fade" id="calendario" role="tabpanel">
                <p class="display-3 fw-bold text-center"><span class="titulo-evento">Próximos eventos</span></p>

            </div>
        </div>
    </div>

</div>
