<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Jóvenes</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold">Salmos 119:9</p>
            <p class="display-6 fw-bold">"¿Con qué limpiará el joven su camino? <span class="text-color-primary">Con guardar tu palabra.</span></p>

            <p class="fs-5">Somos una comunidad vibrante que desafía la corriente.</p>

            <p class="fs-5 mb-3 mt-3"> En un tiempo de muchas voces, elegimos escuchar la de Dios. Buscamos limpiar nuestro camino mediante la Palabra, fomentando amistades sanas, propósito de vida y un compromiso radical para impactar nuestra generación.</p>
            
        </div>

        <div class="col-lg-5 text-center">
            <img style="width: 500px;" src="<?php echo $url; ?>vistas/assets/img/jovenes.png" alt="">
        </div>
    </div>

</div>