<?php include "slider.php"; ?>

<div class="container">
    <div class="section-title mt-4 mb-4 titulo-quienes-somos">
        <h1 class="display-4 fw-bold wow fadeInUp">Iglesia El mesón <span class="text-color-primary">ICEA</span></h1>
    </div>

    <div class="row quienes-somos">
        <div class="col-12 col-lg-4 col-sm-12">
            <p class="mb-2 fs-2 fw-bold wow fadeInUp">¿Quiénes somos?</p>
            <h5 class="mb-3 fs-4 wow fadeInUp" data-wow-delay="0.3s">Eos kasd eos dolor vero vero, lorem stet diam rebum. Ipsum amet sed vero dolor sea</h5>
            <p class=" fs-5 wow fadeInUp" data-wow-delay="0.5s">Takimata sed vero vero no sit sed, justo clita duo no duo amet et, nonumy kasd sed dolor eos diam lorem eirmod. Amet sit amet amet no. Est nonumy sed labore eirmod sit magna. Erat at est justo sit ut. Labor diam sed ipsum et eirmod</p>
            <a href="" class="btn btn-secondary font-weight-bold py-2 px-4 mt-2 wow fadeInUp" data-wow-delay="0.5s">Leer más</a>
        </div>
        <div class="col-12 col-lg-4 col-sm-12 text-center">
            <img src="<?php echo $url; ?>vistas/assets/img/iglesia.png" class="w-75 wow fadeInUp" data-wow-delay=".6s" alt="">
        </div>
        <div class="col-12 col-lg-4 col-sm-12">
            <p class="mb-3 fs-2 fw-bold wow fadeInUp">Lo que hacemos</p>
            <p class=" fs-5 wow fadeInUp" data-wow-delay="0.5s">Invidunt lorem justo sanctus clita. Erat lorem labore ea, justo dolor lorem ipsum ut sed eos, ipsum et dolor kasd sit ea justo. Erat justo sed sed diam. Ea et erat ut sed diam sea ipsum est dolor</p>
            <p class="mb-3 fs-5  wow fadeInUp" data-wow-delay="0.7s"><i class="fa fa-check text-color-primary mr-3"></i> Lorem ipsum dolor sit amet</p>
            <p class="mb-3 fs-5  wow fadeInUp" data-wow-delay="0.8s"><i class="fa fa-check text-color-primary mr-3"></i> Lorem ipsum dolor sit amet</p>
            <p class="mb-3 fs-5  wow fadeInUp" data-wow-delay="0.9s"><i class="fa fa-check text-color-primary mr-3"></i> Lorem ipsum dolor sit amet</p>
            <button class="btn btn-primary font-weight-bold py-2 px-4 mt-2 wow fadeInUp" data-wow-delay="0.5s">Leer más</button>
        </div>
    </div>
</div>


<!-- ========================================================================== -->
<!-- DECLARACIÓN DE FE -->
<!-- ========================================================================== -->
 <section class="section-declaracion-fe section-title mt-5">
    <h1 class="display-1 py-2 mt-4 fw-bold wow fadeInUp">DECLARACIÓN <span class="text-color-primary">DE FE</span></h1>
    
    <div class="container">
        <span class="badge text-bg-light fs-5 d-inline-block declaracion-badge opacity-75 mb-3 wow fadeInUp">
        Nuestra Declaración de fe, resume las verdades fundamentales que creemos, enseñamos y proclamamos, basadas en la autoridad de las Sagradas Escrituras
        </span>

        <div class="row px-5 mt-3">
            <?php
                $declaraciones_fe = ControladorConocenos::ctrMostrarDeclaraciones(null, null);

                foreach ($declaraciones_fe as $key => $value) {

                    $animacion = ($key % 2) == 0 ? "fadeInLeft" : "fadeInRight";

                    echo "
                        <div class='col-lg-6 col-sm-12 wow {$animacion}'>
                            <div class='declaracion-item d-flex '>
                                <strong class='declaracion-numeral'>{$value["numero"]}</strong>
                                <div class='declaracion-texto'>
                                    <p class='fs-6 text-color-primary mb-0'>{$value["titulo"]}</p>
                                    <p class='description mb-0'>{$value["descripcion"]}</p>
                                    <p class='opacity-75 versiculo'>{$value["versiculo"]}</p>
                                </div>
                            </div>
                        </div>
                    ";
                }

            ?>
        </div>
    </div>
 </section>

 <!-- ========================================================================== -->
 <!-- MISIÓN Y VISIÓN -->
  <!-- ========================================================================== -->
<div class="container-fluid">
    <div class="row">
        <div class="mision-vision">
            <div class="col-lg-4 col-sm-12 d-flex align-items-center mision wow fadeInUp">
                <p class="fs-3 fw-bold d-none">MISIÓN</p>
                <p class="fs-5">Somos una iglesia llamada a ser un refugio de restauración y esperanza, predicando el Evangelio de Jesucristo para transformar vidas, discipular creyentes y servir a nuestra comunidad con amor práctico.</p>
            </div>
            <div class="col-lg-4 col-sm-12 d-flex align-items-center text-center justify-content-center img-mision-vision wow fadeInUp" data-wow-delay="0.2s">
                <img src="<?php echo $url; ?>vistas/assets/img/mision-vision.png" class="w-75" alt="">
            </div>
            <div class="col-lg-4 col-sm-12 d-flex align-items-center vision wow fadeInUp" data-wow-delay="0.4s">
                <p class="fs-3 fw-bold d-none">VISIÓN</p>
                <p class="fs-5">Ser una iglesia referente en España por su pasión por Dios y compasión por las personas; consolidando familias fuertes, extendiendo el Reino de Dios a través de las misiones y siendo un agente activo de transformación social.</p>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================== -->
<!-- VALORES -->
<!-- ========================================================================== -->
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-5">
            <div class="nuestros-valores-pilares fondo-con-overlay">
                <span class="wow fadeInLeft">
                    <div class="contenido-tarjeta">
                        <p class="display-4 fw-bold text-white">Nuestros valores</p>
                    </div>
                </span>
            </div>
        </div>
        <div class="col-lg-7 d-flex">
            <div class="row valores">
                <?php
                    $nuestros_valores = ControladorConocenos::ctrMostrarValoresPilares(null, null, "valores");
                    foreach ($nuestros_valores as $key => $value) {
                       echo "
                        <div class='col-lg-6 col-sm-12 px-2 wow fadeInUP'>
                            <i class='fa fa-caret-down'></i>
                            <p class='fs-4 fw-bold mb-0 titulo-valores'>{$value["titulo"]}</p>
                            <p class=' fs-5'>{$value["descripcion"]}</p>
                        </div>
                       ";
                    }
                ?>

            </div>
        </div>
    </div>
</div>

<hr class="mx-5">

<!-- ========================================================================== -->
<!-- PILARES -->
 <!-- ========================================================================== -->
<div class="container">
    <div class="row nuestros-pilares">
        <div class="col-lg-7 d-flex">
            <div class="row pilares">
                <?php
                    $nuestros_pilares = ControladorConocenos::ctrMostrarValoresPilares(null, null, "pilares");
                    foreach ($nuestros_pilares as $key => $value) {
                        echo "
                            <div class='col-lg-6 px-2 wow fadeInUp'>
                                <i class='fa fa-caret-down'></i>
                                <p class='fs-4 fw-bold mb-0 titulo-pilares'>{$value["titulo"]}</p>
                                <p class='v-descripcion fs-5'>{$value["descripcion"]}</p>
                            </div>
                        ";
                    }
                ?>

            </div>
        </div>
        <div class="col-lg-5">
            <div class="nuestros-valores-pilares color fondo-con-overlay">
                <span class="cover-pilares wow fadeInRight">
                    <div class="contenido-tarjeta">
                        <p class="display-4 fw-bold text-white">Nuestros Pilares</p>
                    </div>
                </span>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================== -->
<!-- Nuestro equipo de trabajo -->
 <!-- ========================================================================== -->
<section class="position-relative min-vh-100 mt-5 team-work">
  
  <div class="container section-title position-relative z-1 mt-2">
    <h1 class="display-4 wow fadeInUp">NUESTRO <span class="text-color-primary">EQUIPO DE TRABAJO</span></h1>
    <p class="px-5 wow fadeInUp">
        <span class="px-5 fs-4 team-work-frase">Somos un equipo unido por la fe y el amor de Dios. Servimos con humildad, compromiso y pasión. Nuestro propósito es edificar vidas y compartir esperanza.</span>
    </p>

    <div class="owl-carousel team-carousel overlay-bottom overlay-top py-5 px-4">

        <?php
            $equipo = ControladorConocenos::ctrMostrarColaboradores(null, null);
            
            foreach ($equipo as $key => $value) {
                echo "
                <div class='team-item'>
                    <div class='team-header'>
                        <img src='{$urlImg}vistas/assets/img/colaboradores/{$value["foto_perfil"]}' alt='' class='wow fadeInUp'>
                    </div>
                    <p class='wow fadeInUp'>
                        <h5 class='wow fadeInUp fw-bold' data-wow-delay='0.8s'>{$value["nombre"]}</h5>
                        <span class='wow fadeInUp' data-wow-delay='0.8s'>{$value["cargo"]}</span>
                    </p>
                </div>
                ";
            }
        ?>

    </div>

  </div>
</section>

<!-- ========================================================================== -->
<!-- FORMULARIO -->
 <!-- ========================================================================== -->
<div class="container-fluid pt-2">
    <div class="container">
        <div class="section-title mb-4 mt-2">
            <h1 class="display-4 wow fadeInUp">Háblanos de ti, nos encantará saber tu <span class="text-color-primary fw-bold">testimonio</span></h1>
            <span class="text-black-50 fs-4 wow fadeInUp">También puedes realizarnos consultas, estaremos encantados de poder ayudarte.</span>
            <form class="py-3" action="" method="post" id="formulario-escribenos">
                <input class="mr-3 wow fadeInUp" type="text" placeholder="Nombre" maxlength="30">
                <input class="wow fadeInUp" type="text" placeholder="Apellido" maxlength="30">
                <br>
                <input class="wow fadeInUp" type="text" placeholder="Correo electrónico" maxlength="50">
                <br>
                <button type="button" class="btn btn-outline-secondary wow wobble">Enviar</button>
            </form>
        </div>
        <div class="row">
            
        </div>
    </div>
</div>