<div class="container-fluid footer text-white mt-5 pt-5 px-0 position-relative overlay-top">
    <div class="row mx-0 pt-5 px-sm-3 px-lg-5 mt-4">
        <div class="col-lg-3 col-md-6 mb-5">
            <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Contáctanos</h4>
            <p><i class="fa fa-map-marker-alt mr-2"></i>123 Street, New York, USA</p>
            <p><i class="fa fa-phone-alt mr-2"></i>+012 345 67890</p>
            <p class="m-0"><i class="fa fa-envelope mr-2"></i>info@example.com</p>
        </div>
        <div class="col-lg-3 col-md-6 mb-5">
            <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Síguenos</h4>
            <p>Amet elitr vero magna sed ipsum sit kasd sea elitr lorem rebum</p>
            <div class="d-flex justify-content-start">
                <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="#"><i class="fab fa-twitter"></i></a>
                <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-lg btn-outline-light btn-lg-square mr-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                <a class="btn btn-lg btn-outline-light btn-lg-square" href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-5">
            <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">Nuestros horarios</h4>
            <div>
                <h6 class="text-white text-uppercase">Monday - Friday</h6>
                <p>8.00 AM - 8.00 PM</p>
                <h6 class="text-white text-uppercase">Saturday - Sunday</h6>
                <p>2.00 PM - 8.00 PM</p>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-5">
            <h4 class="text-white text-uppercase mb-4" style="letter-spacing: 3px;">DONACIONES</h4>
            <p>Tu generosidad transforma vidas y extiende el amor de Dios</p>
            <div class="w-100">
                <div class="input-group input-email">
                    <div class="input-group-append">
                        <button class="btn btn-primary font-weight-bold px-3" data-bs-toggle="modal" data-bs-target="#ModalDonaciones">Quiero donar <i class="fa fa-hand-point-up"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid text-center text-white border-top mt-4 py-4 px-sm-3 px-md-5 copyright">
        <p class="mb-2 text-white">Copyright &copy; <a class="text-color-primary" href="#">El Mesón ICEA</a>. Todos los derechos reservados.</a></p>
    </div>
</div>

<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


        <!-- Modal para donaciones -->
<div class="modal fade" id="ModalDonaciones" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="ModalDonacionesLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <!-- DONACIONES -->
                <div class="container-fluid text-center position-relative my-2">
                    <div class="container py-2">
                        <h1 class="display-4 text-color-primary">DONAR ES <span class="bg-primary text-white px-3 py-2 mb-0 fw-bold">SEMBRAR</span></h1>
                        <img class="img-donacion" src="<?php echo $url; ?>vistas/assets/img/donacion.png" alt="">
                        <!-- <h1 class="text-white mb-3">Sunday Special Offer</h1> -->
                        <p class="text-color-primary mt-2 mb-0 pb-1 fs-5 fw-bold">Puedes apoyar a este ministerio a través de una donación</p>
                        <span class="text-grey-50 fs-5">Cada aporte ayuda a que nuestra comunidad siga creciendo y llevando luz a quienes nos rodean.</span>
                        <br><br>
                        <button type="button" class="btn btn-primary fs-4 btn-donacion my-2 py-2">Apoyar esta misión
                            <i class="fa fa-heart"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>