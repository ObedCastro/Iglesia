<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Ministerio de alabanza</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold">Salmos 150:6</p>
            <p class="display-6 fw-bold">Todo lo que respira alabe a JAH.</p>

            <p class="fs-5">Un equipo de levitas comprometidos con la excelencia musical y espiritual</p>

            <p class="fs-5 mb-3 mt-3">Nuestro propósito no es dar un espectáculo, sino preparar la atmósfera y guiar a la congregación, a través de la música y el cántico, a un encuentro íntimo y transformador con la presencia de Dios.</p>
            
        </div>

        <div class="col-lg-5 text-center">
            <img style="width: 400px; box-shadow: -10px 10px rgba(0, 0, 0, 0.25); border-radius: 15px" src="<?php echo $url; ?>vistas/assets/img/alabanza.avif" alt="">
        </div>
    </div>

</div>