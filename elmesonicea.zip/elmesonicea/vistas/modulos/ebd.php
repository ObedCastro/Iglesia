<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Escuela bíblica dominical</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold">Marcos 10:14</p>
            <p class="display-6 fw-bold">Dejad a los niños venir a mí, y no se lo impidáis</p>
            <p class="fs-5">Un espacio exclusivo y seguro para los más pequeños durante nuestros servicios dominicales </p>

            <p class="fs-5 mb-3 mt-3">Mientras los adultos reciben la Palabra, los niños son instruidos con enseñanzas bíblicas adaptadas a su edad, aprendiendo a amar a Jesús desde la infancia.</p>
            
        </div>

        <div class="col-lg-5 text-center">
            <img style="width: 350px;" src="<?php echo $url; ?>vistas/assets/img/escuela-biblica.png" alt="">
        </div>
    </div>

</div>