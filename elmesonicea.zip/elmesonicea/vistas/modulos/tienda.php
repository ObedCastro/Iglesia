<div class="container-fluid learning"></div>

<div class="container pb-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Tienda</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-12">
            <p class="text-color-success fw-bold">Colosenses 4:5-6</p>
            <p class="display-6 fw-bold">Aprovechando bien el tiempo para con los de afuera, sea vuestra palabra siempre con gracia</p>
            <p class="fs-5">Más que una tienda de artículos para el hogar y muebles, somos un punto de encuentro con la comunidad. Un espacio donde las personas vienen buscando algo para su casa, pero a menudo encuentran consuelo para su alma.</p>
            <p class="fs-5 fw-bold mb-3">A través de la atención personalizada, oramos y compartimos a Cristo con nuestros vecinos.</p>
            
            <div class="dorcas d-flex">
                Búscanos en 
                <a class="enlaces-dorcas" href="#">
                    <span class="fs-5 fw-bold px-2">Facebook</span>
                </a>

                <p class="mt-2">O visítanos en</p>
                <span class="fs-5 fw-bold px-2">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13330619.54770141!2d-17.595888855318304!3d35.342099101709266!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xc42e3783261bc8b%3A0xa6ec2c940768a3ec!2zRXNwYcOxYQ!5e0!3m2!1ses!2ssv!4v1768423832365!5m2!1ses!2ssv" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </span>
            </div>
        </div>
    </div>

</div>