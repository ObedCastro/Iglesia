<div class="container-fluid slider-portada ">
    <div class="row py-2">
        <div class="col-lg-12">
            <div class="container texto-portada text-center">
                <p class="display-4 text-white fw-bold">RECURSOS</p>
                <p class="text-white-50">Esta es una sección donde podrás ver recursos que compartimos para ti y tu edificación.</p>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <p class="display-6 fw-bold text-center my-5">¿Qué encontrarás aquí?</p>
</div>

<div class="row container mt-5 px-5 m-auto">
    <div class="col-lg-12 d-flex align-items-center justify-content-center">
        <div class="text-end">
            <p class="fs-3 fw-bold mb-0"><span class="text-color-primary">Nuestras raíces</span></p>
            <p class="fs-5 mb-3">Acceso al registro histórico y mensajes de nuestro fundador.</p>
            <a href="https://webclasica.iglesiasicea.es/" target="_blank" type="button" class="btn btn-dark fw-bold px-3">Ver recursos</a>
        </div>

        <img style="width: 300px;" src="<?php echo $url; ?>vistas/assets/img/recursos-1.svg" alt="">
    </div>

    <hr>

    <div class="col-lg-12 d-flex align-items-center justify-content-center">
        <img style="width: 300px;" src="<?php echo $url; ?>vistas/assets/img/recursos-1.svg" alt="">

        <div>
            <p class="fs-3 fw-bold mb-0"><span class="text-color-primary">Prédicas online</span></p>
            <p class="fs-5 mb-3">Disfruta de nuestras reuniones dominicales y enseñanzas recientes en nuestro canal oficial.</p>
            <a href="https://youtube.com/@iceafinca1976?si=Dvwz8h19Jpo1tdtH" target="_blank" type="button" class="btn btn-dark fw-bold px-3">Ver recursos</a>
        </div>
    </div>

    <div class="col-lg-12 mt-2 mb-5">
        <div class="container">
            <p class="display-6 fw-bold text-center my-3">Algunas de nuestras prédicas</p>
        </div>
        
        <div class="predicas-videos d-flex">

            <div class="youtube-preview" data-id="P6nXVulocO0">
                <img src="https://img.youtube.com/vi/P6nXVulocO0/hqdefault.jpg" alt="Video de YouTube">
                <div class="play-button"></div>
            </div>
            
            <div class="youtube-preview" data-id="P6nXVulocO0">
                <img src="https://img.youtube.com/vi/P6nXVulocO0/hqdefault.jpg" alt="Video de YouTube">
                <div class="play-button"></div>
            </div>
            
            <div class="youtube-preview" data-id="P6nXVulocO0">
                <img src="https://img.youtube.com/vi/P6nXVulocO0/hqdefault.jpg" alt="Video de YouTube">
                <div class="play-button"></div>
            </div>
            
            <div class="youtube-preview" data-id="P6nXVulocO0">
                <img src="https://img.youtube.com/vi/P6nXVulocO0/hqdefault.jpg" alt="Video de YouTube">
                <div class="play-button"></div>
            </div>
            
            <div class="youtube-preview" data-id="P6nXVulocO0">
                <img src="https://img.youtube.com/vi/P6nXVulocO0/hqdefault.jpg" alt="Video de YouTube">
                <div class="play-button"></div>
            </div>
        </div>
    </div>

</div>