<nav class="navbar navbar-expand-lg position-absolute" id="navbar">
  <div class="container-fluid">

    <!-- Logo izquierda -->
    <a class="navbar-brand fw-bold" href="<?php echo $url; ?>">
      <img src="<?php echo $url; ?>vistas/assets/img/logo-iglesia.png" alt="Logo" height="32" class="me-2 logo-nav">
    </a>

    <!-- Toggle mobile -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menú centrado en la página -->
    <div class="collapse navbar-collapse justify-content-center menu-center" id="mainNavbar">
      <ul class="navbar-nav align-items-lg-center">

        <li class="nav-item mx-1">
          <a class="nav-link nav-underline active" href="<?php echo $url; ?>">CONÓCENOS</a>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>

        <li class="nav-item mx-1">
          <!-- <a class="nav-link" href="#">RED</a> -->

            <button type="button" class="nav-link nav-underline popover-menu"
                    data-bs-toggle="popover" data-bs-placement="bottom" 
                    data-bs-html="true"
                    data-bs-custom-class="custom-popover"
                    data-bs-content="
                        <div class='list-group'>
                            <a href='dorcas' class='list-group-item list-group-item-action'>Ministerio Dorcas</a>
                            <a href='alabanza' class='list-group-item list-group-item-action'>Ministerio de alabanza</a>
                            <a href='danza' class='list-group-item list-group-item-action'>Ministerio de danza</a>
                            <a href='tienda' class='list-group-item list-group-item-action'>Tienda El Encuentro</a>
                            <a href='jovenes' class='list-group-item list-group-item-action'>Jóvenes</a>
                            <a href='adolescentes' class='list-group-item list-group-item-action'>Adolescentes</a>
                            <a href='ebd' class='list-group-item list-group-item-action'>Escuela dominical</a>
                            <a href='misiones' class='list-group-item list-group-item-action'>Misiones</a>
                        </div>
                    ">
                    MINISTERIOS <i class="fa fa-solid fa-caret-down arrow-menu"></i>
            </button>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>

        <li class="nav-item mx-1">
          <a class="nav-link nav-underline" href="eventos">EVENTOS</a>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>
        
        <li class="nav-item mx-1">
          <a class="nav-link nav-underline" href="recursos">RECURSOS</a>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>
        
        <li class="nav-item mx-1">
          <!-- <a class="nav-link nav-underline" href="#">LA FINCA</a> -->

          <button type="button" class="nav-link nav-underline popover-menu" 
                    data-bs-toggle="popover" data-bs-placement="bottom" 
                    data-bs-html="true"
                    data-bs-custom-class="custom-popover"
                    data-bs-content="
                        <div class='list-group'>
                            <a href='voluntariado' class='list-group-item list-group-item-action'>Voluntariado</a>
                            <a href='rehabilitacion' class='list-group-item list-group-item-action'>Recupérate</a>
                            <a href='social' class='list-group-item list-group-item-action'>Actividades sociales</a>
                        </div>
                    ">
                    ACCIÓN SOCIAL<i class="fa fa-solid fa-caret-down arrow-menu"></i>
            </button>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>
        
        <li class="nav-item mx-1">
          <a class="nav-link last-item-nav px-2 mx-2" href="learning">LEARNING EL MESÓN</a>
        </li>

      </ul>
    </div>

    <!-- Botón derecha -->
    <div class="d-lg-flex">
        <div class="dropdown dropstart">
            <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Idioma
            </button>
            <ul class="dropdown-menu dropdown-menu-white">
                <li><a class="dropdown-item active" href="#">Español</a></li>
                <li><a class="dropdown-item" href="#">Inglés</a></li>
            </ul>

            <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#ModalDonaciones">Donar</button>
        </div>
    </div>

  </div>
</nav>
