<div class="container-fluid learning"></div>


<div class="container py-2 mt-5">
    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold"><i class="fa fa-graduation-cap"></i> Aprende con nosotros.</p>
            <p class="display-4 fw-bold">Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            <p class="fs-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, maiores necessitatibus. Assumenda, officiis, consequatur facere.</p>
            
            <div class="py-2">
                <span class="fs-4 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> Flexible</span>
                <span class="fs-4 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> Flexible</span>
                <span class="fs-4 fw-bold px-2"><i class="fa fa-check px-2 text-color-primary"></i> Flexible</span>
            </div>
        </div>

        <div class="col-lg-5 img-learning">
            <img src="<?php echo $url; ?>vistas/assets/img/learning.png" alt="">
        </div>
    </div>

</div>