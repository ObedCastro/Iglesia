<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Adolescentes</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold">1 Timoteo 4:12</p>
            <p class="display-6 fw-bold">Ninguno tenga en poco tu juventud, sino sé ejemplo de los creyentes en palabra, conducta, amor, espíritu, fe y pureza.</p>
            <p class="fs-5">Un espacio diseñado para acompañarles en una etapa de cambios y descubrimientos. </p>

            <p class="fs-5 mb-3 mt-3">No solo les enseñamos, sino que les empoderamos para que, sin importar su edad, sean ejemplo en palabra, conducta, amor y fe, cimentando su identidad en Jesús en medio de un mundo confuso.</p>
            
        </div>

        <div class="col-lg-5 text-center">
            <img style="width: 500px;" src="<?php echo $url; ?>vistas/assets/img/adolescentes.png" alt="">
        </div>
    </div>

</div>