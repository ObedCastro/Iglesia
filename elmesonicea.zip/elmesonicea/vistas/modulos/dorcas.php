<div class="container-fluid learning"></div>

<div class="container py-2">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Ministerio Dorcas</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold">Provervios 31:30</p>
            <p class="display-6 fw-bold">Engañosa es la gracia, y vana la hermosura; la mujer que teme a Jehová, esa será alabada.</span></p>

            <p class="fs-4">Más que un grupo, somos una red de apoyo, oración y servicio.</p>

            <p class="fs-4 mb-3 mt-3"> Mujeres que entienden que la verdadera belleza radica en el temor de Dios. Nos dedicamos a la edificación mutua y a extender una mano de ayuda práctica y amorosa dentro y fuera de la iglesia.</p>
            
        </div>

        <div class="col-lg-5 text-center">
            <img style="width: 500px; box-shadow: -10px 10px rgba(0, 0, 0, 0.25); border-radius: 15px" src="<?php echo $url; ?>vistas/assets/img/dorcas.avif" alt="">
        </div>
    </div>

</div>