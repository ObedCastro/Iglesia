<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Ministerio de danza</li>
            <hr>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-7">
            <p class="text-color-success fw-bold">Salmos 149:3</p>
            <p class="display-6 fw-bold">Alaben su nombre con danza.</p>

            <p class="fs-5">Adoración en movimiento.</p>

            <p class="fs-5 mb-3 mt-3">Utilizamos las artes creativas y la expresión corporal para exaltar el nombre de Dios, transmitiendo mensajes de libertad, gozo y victoria que edifican al cuerpo de Cristo y rompen cadenas espirituales.</p>
            
        </div>

        <div class="col-lg-5 text-center">
            <img style="width: 300px; box-shadow: -10px 10px rgba(0, 0, 0, 0.25); border-radius: 15px" src="<?php echo $url; ?>vistas/assets/img/danza.jpg" alt="">
        </div>
    </div>

</div>