<div class="container-fluid learning"></div>

<div class="container py-2 mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item migas-home"><a href="conocenos">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Recupérate</li>
            <hr>
        </ol>
    </nav>

    <div class="row mb-5">
        <div class="col-lg-12">
            <div class="container d-flex">
                <div class="col-6 px-4">
                    <img width="500px" src="<?php echo $url; ?>vistas/assets/img/inclusion.svg" alt="">
                </div>
                
                <div class="col-6 px-4">
                    <p class="fs-4 mb-3">Ofrecemos un programa integral de desintoxicación y rehabilitación parapersonas en situación de dependencia o exclusión social.</p>

                    <p class="fs-4 mb-3">Contamos con instalaciones adecuadas y un equipo de apoyo dedicado a la recuperación personal y la reintegración a la sociedad.</p>

                    <button class="btn btn-outline-dark p-3 fw-bold">Solicitar ingreso o información <i class="fa fa-arrow-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <hr>
    <br>

    <div class="container contacto-directo text-center mt-4" style="padding: 10px; box-shadow: 0 0 20px #e3e3e3ff; width: 300px; border-radius: 20px;">
        <i class="fa fa-phone fs-1 mb-3"></i>
        <p class="mb-0">CONTACTO DIRECTO</p>
        <p class="fw-bold fs-5 mb-0">952 111 068</p>
    </div>

</div>