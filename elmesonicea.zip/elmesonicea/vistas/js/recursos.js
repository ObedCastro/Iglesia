
document.querySelectorAll('.youtube-preview').forEach(el => {
el.addEventListener('click', () => {
    const id = el.dataset.id;
    el.innerHTML = `
    <iframe
        width="100%"
        height="315"
        src="https://www.youtube.com/embed/${id}?autoplay=1"
        frameborder="0"
        allow="autoplay; clipboard-write; encrypted-media"
        allowfullscreen>
    </iframe>`;
    });
});
