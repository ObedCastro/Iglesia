/* Navbar */

const navbar = document.getElementById("navbar");

  window.addEventListener("scroll", () => {
    if (window.scrollY > 60) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  });

/* Botón para regresar al principio de la página */
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });

    /* CONTENIDO DINÁMICO EN SLIDER */
    const autoTypeElement = document.querySelector('.auto-type');
    if(autoTypeElement){
        new Typed('.auto-type', {
            strings: ['Adorar', 'Servir', 'Predicar', 'Vivir para su gloria'],
            typeSpeed: 100,
            backSpeed: 100,
            loop: true
        });
    }

    /* Habilitar popovers */
    const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');

popoverTriggerList.forEach(popoverTriggerEl => {
    const popover = new bootstrap.Popover(popoverTriggerEl, {
        trigger: 'manual', // Controlaremos el trigger manualmente
        html: true,
        animation: true
    });

    let timeout;

    // Al entrar al botón
    popoverTriggerEl.addEventListener('mouseenter', () => {
        clearTimeout(timeout);
        popover.show();
        
        // Necesitamos agregar eventos al contenido del popover una vez que aparece
        const popoverElement = document.querySelector('.popover');
        if (popoverElement) {
            popoverElement.addEventListener('mouseenter', () => clearTimeout(timeout));
            popoverElement.addEventListener('mouseleave', () => {
                timeout = setTimeout(() => popover.hide(), 150);
            });
        }
    });

    // Al salir del botón
    popoverTriggerEl.addEventListener('mouseleave', () => {
        timeout = setTimeout(() => {
            // Solo cerramos si el mouse no está sobre un popover abierto
            if (!document.querySelector('.popover:hover')) {
                popover.hide();
            }
        }, 150);
    });
});

/* NUESTRO EQUIPO DE TRABAJO */
$(document).ready(function(){
    $('.team-carousel').owlCarousel({
        loop: true,
        margin: 40,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        smartSpeed: 800,
        dots: true,
        nav: false,
        responsive:{
        0:{
            items:1
        },
        768:{
            items:2
        },
        992:{
            items:5
        }
        }
    });
});