<?php

class ControladorEventos{

    /* MOSTRAR EVENTOS */
    static public function ctrMostrarEventos($item, $valor){
        $tabla = "eventos";
        $slider = Modeloeventos::mdlMostrarEventos($tabla, $item, $valor);
        return $slider;
    }

}