<?php

class ControladorConocenos{

    /* ================================================================================= */
    /* DECLARACIONES DE FE */
    /* ================================================================================= */
    
     /* MOSTRAR INFORMACIÓN DE DECLARACIÓN DE FE */
    static public function ctrMostrarDeclaraciones($item, $valor){
        $tabla = "declaraciones_de_fe";
        $declaraciones = ModeloConocenos::mdlMostrarDeclaraciones($tabla, $item, $valor);
        return $declaraciones;
    }



    /* ================================================================================= */
    /* COLABORADORES */
    /* ================================================================================= */
    
     /* MOSTRAR INFORMACIÓN DE COLABORADORES*/
    static public function ctrMostrarColaboradores($item, $valor){
        $tabla = "colaboradores";
        $colaboradores = ModeloConocenos::mdlMostrarColaboradores($tabla, $item, $valor);
        return $colaboradores;
    }


    /* ================================================================================= */
    /* NUESTROS VALORES Y NUESTROS PILARES */
    /* ================================================================================= */
    
    /* MOSTRAR INFORMACIÓN DE NUESTROS VALORES Y NUESTROS PILARES */
    static public function ctrMostrarValoresPilares($item, $valor, $tipo){
        if($tipo == "valores"){
            $tabla = "nuestros_valores";
        } else if($tipo == "pilares"){
            $tabla = "nuestros_pilares";
        }
    
        $valores_pilares = ModeloConocenos::mdlMostrarValoresPilares($tabla, $item, $valor);
        return $valores_pilares;
    }

}