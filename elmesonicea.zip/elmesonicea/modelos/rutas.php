<?php

class Rutas{

    static public function mdlRuta(){
        return "http://localhost/elmesonicea/";
    }
    
    static public function mdlRutaImg(){
        return "http://localhost/elmesonicea.backend/";
    }

}