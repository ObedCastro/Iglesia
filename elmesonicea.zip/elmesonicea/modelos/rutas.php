<?php

class Rutas{

    static public function mdlRuta(){
        return "http://localhost/elmesonicea/";
    }

}