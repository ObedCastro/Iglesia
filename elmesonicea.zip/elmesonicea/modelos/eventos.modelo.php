<?php

require_once "conexion.php";

class ModeloEventos{

    /* MOSTRAR EVENTOS */
    public static function mdlMostrarEventos($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT e.id as evento_id, e.titulo as evento_titulo, e.descripcion as evento_descripcion, e.fecha as evento_fecha, eg.id as imagen_id, eg.imagen as imagen_archivo, eg.titulo as imagen_titulo, eg.descripcion as imagen_descripcion FROM $tabla e LEFT JOIN eventos_galeria eg ON eg.id_evento = e.id WHERE e.activo = 1";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $eventos = [];

            foreach ($resultado as $row) {

                $id = $row["evento_id"];

                if (!isset($eventos[$id])) {
                    $eventos[$id] = [
                        "id" => $id,
                        "titulo" => $row["evento_titulo"],
                        "descripcion" => $row["evento_descripcion"],
                        "fecha" => $row["evento_fecha"],
                        "galeria" => []
                    ];
                }

                $eventos[$id]["galeria"][] = [
                    "id" => $row["imagen_id"],
                    "imagen" => $row["imagen_archivo"],
                    "titulo" => $row["imagen_titulo"],
                    "descripcion" => $row["imagen_descripcion"]
                ];
            }

            return array_values($eventos);

        }
    }

}