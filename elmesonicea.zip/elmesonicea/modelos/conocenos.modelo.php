<?php

require_once "conexion.php";

class ModeloConocenos{

    /* ================================================================================= */
    /* DECLARACIONES DE FE */
    /* ================================================================================= */
    
    /* MOSTRAR DECLARACIONES DE FE */
    public static function mdlMostrarDeclaraciones($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla WHERE activo = 1";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }



    /* ================================================================================= */
    /* COLABORADORES */
    /* ================================================================================= */
    
    /* MOSTRAR COLABORADORES */
    public static function mdlMostrarColaboradores($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla WHERE activo = 1";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }


    /* ================================================================================= */
    /* NUESTROS VALORES Y NUESTROS PILARES */
    /* ================================================================================= */
    
    /* MOSTRAR NUESTROS VALORES Y NUESTROS PILARES */
    public static function mdlMostrarValoresPilares($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla WHERE activo = 1";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }

}