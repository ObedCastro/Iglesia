<?php

/* CONTROLADORES */
require_once "controladores/base.controlador.php";
require_once "controladores/conocenos.controlador.php";
require_once "controladores/eventos.controlador.php";

/* MODELOS */
require_once "modelos/rutas.php";
require_once "modelos/conocenos.modelo.php";
require_once "modelos/eventos.modelo.php";



/* Llamando a la plantilla base */
$base = new ControladorBase();
$base->base();