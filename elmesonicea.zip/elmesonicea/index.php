<?php

/* CONTROLADORES */
require_once "controladores/base.controlador.php";

/* MODELOS */
require_once "modelos/rutas.php";



/* Llamando a la plantilla base */
$base = new ControladorBase();
$base->base();