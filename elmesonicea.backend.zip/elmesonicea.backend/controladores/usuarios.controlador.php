<?php

const RUTA = "http://localhost/elmesonicea.backend/";

class ControladorUsuarios{

    /* INICIAR SESIÓN */
    public function ctrIngresarUsuarios(){
        $expresionPassword = '/^[a-zA-Z0-9]+$/';

        if(isset($_POST['usuario'])){
            if($_POST['usuario'] && preg_match($expresionPassword, $_POST['password'])){
                $tabla = "usuarios";
                $item = "usuario";
                $valor = $_POST['usuario'];
                $passInput = md5($_POST["password"]);
                
                $respuesta = ModeloUsuarios::mdlIngresarUsuarios($tabla, $item, $valor);

                if(is_array($respuesta) && $respuesta["usuario"] == $_POST["usuario"] && $respuesta["password"] == $passInput){
                    $_SESSION["validarSesion"] = "ok";
                    $_SESSION["id"] = $respuesta["id"];
                    $_SESSION["nombre"] = $respuesta["nombre"];
                    $_SESSION["correo"] = $respuesta["correo"];
                    $_SESSION["foto"] = $respuesta["foto"];
                    $_SESSION["cargo"] = $respuesta["cargo"];
                    $_SESSION["usuario"] = $respuesta["usuario"];
                    $_SESSION["password"] = $respuesta["password"];                

                    header("Location: ".RUTA."inicio");


                }else{                    
                    echo '<br><div class="text-danger text-bold">
                            Error: Ingrese datos válidos.
                        </div>';
                } 
            }
        } 
    }

    /* LISTAR USUARIOS */
    static public function ctrMostrarUsuarios($item, $valor){
        $tabla = "usuarios";
        $datos = ModeloUsuarios::mdlMostrarUsuarios($tabla, $item, $valor);

        return $datos;
    }

}