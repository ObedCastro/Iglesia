<?php

const RUTA = "http://localhost/elmesonicea.backend/";

class ControladorUsuarios{

    /* INICIAR SESIÓN */
    public function ctrIngresarUsuarios(){
        $expresionPassword = '/^[a-zA-Z0-9]+$/';

        if(isset($_POST['usuario'])){
            if($_POST['usuario'] && preg_match($expresionPassword, $_POST['password'])){
                $tabla = "usuarios";
                $item = "usuario";
                $valor = $_POST['usuario'];
                $passInput = md5($_POST["password"]);
                
                $respuesta = ModeloUsuarios::mdlIngresarUsuarios($tabla, $item, $valor);

                if(is_array($respuesta) && $respuesta["usuario"] == $_POST["usuario"] && $respuesta["password"] == $passInput){
                    $_SESSION["validarSesion"] = "ok";
                    $_SESSION["id"] = $respuesta["id"];
                    $_SESSION["nombre"] = $respuesta["nombre"];
                    $_SESSION["correo"] = $respuesta["correo"];
                    $_SESSION["foto"] = $respuesta["foto"];
                    $_SESSION["cargo"] = $respuesta["cargo"];
                    $_SESSION["usuario"] = $respuesta["usuario"];
                    $_SESSION["password"] = $respuesta["password"];                

                    header("Location: ".RUTA."conocenos");


                }else{                    
                    echo '<br><div class="text-danger text-bold">
                            Error: Ingrese datos válidos.
                        </div>';
                } 
            }
        } 
    }

    /* LISTAR USUARIOS */
    static public function ctrMostrarUsuarios($item, $valor){
        $tabla = "usuarios";
        $datos = ModeloUsuarios::mdlMostrarUsuarios($tabla, $item, $valor);

        return $datos;
    }

    /* CAMBIAR FOTO DE PERFIL DEL USUARIO */
    static public function ctrCambiarFotoPerfilUsuario($nombreImgGuardar, $idUsuario){
        $tabla = "usuarios";
        $respuesta = ModeloUsuarios::mdlCambiarFotoUsuario($tabla, $nombreImgGuardar, $idUsuario);

        if($respuesta == "ok"){
            return array("mensaje" => "Su foto de perfil ha sido cambiada con éxito.", "icono" => "success", "titulo" => "Éxito");
        } else{
            return array("mensaje" => "No fue posible cargar el archivo.", "icono" => "error", "titulo" => "Algo salió mal");
        }
    }

    /* CAMBIAR CONTRASEÑA DE USUARIO */
    static public function ctrCambiarPasswordUsuario($item, $valor, $pass){
        $tabla = "usuarios";
        $respuesta = ModeloUsuarios::mdlCambiarPasswordUsuario($tabla, $item, $valor, $pass);

        if($respuesta == "ok"){
            return array("mensaje" => "Contraseña cambiada satisfactoriamente.", "icono" => "success", "titulo" => "Éxito");
        } else{
            return array("mensaje" => $respuesta, "icono" => "error", "titulo" => "Algo salió mal.");
        }
    }

}