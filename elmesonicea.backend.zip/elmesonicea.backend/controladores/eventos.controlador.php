<?php

class ControladorEventos {

    /* REGISTRAR NUEVO EVENTO */
    static public function ctrGuardarEvento($evento, $imagenes, $titulos, $descripciones) {

        $idEvento = ModeloEventos::mdlCrearEvento("eventos", $evento);

        if (!$idEvento) {
            return [
                "icono" => "error",
                "titulo" => "Error",
                "mensaje" => "No se pudo crear el evento"
            ];
        }

        $ruta = $_SERVER['DOCUMENT_ROOT']."/elmesonicea.backend/vistas/assets/img/eventos/";

        for ($i = 0; $i < count($titulos); $i++) {

            if (isset($imagenes["error"][$i]) && $imagenes["error"][$i] == 0) {

                $nombre = uniqid() . "_" . $imagenes["name"][$i];
                $rutaFinal = $ruta . $nombre;

                $tipo = $imagenes["type"][$i];
                if ($tipo != "image/jpeg" && $tipo != "image/png") {
                    continue;
                }

                move_uploaded_file($imagenes["tmp_name"][$i], $rutaFinal);

                $datosImg = [
                    "id_evento" => $idEvento,
                    "imagen" => $nombre,
                    "titulo" => $titulos[$i],
                    "descripcion" => $descripciones[$i]
                ];

                ModeloEventos::mdlGuardarImagen("eventos_galeria", $datosImg);
            }
        }


        return [
            "icono" => "success",
            "titulo" => "Evento creado",
            "mensaje" => "El evento y su galería fueron guardados"
        ];
    }


    /* MOSTRAR EVENTOS */
    static public function ctrMostrarEventos($item, $valor){
        $tabla = "eventos";
        $slider = Modeloeventos::mdlMostrarEventos($tabla, $item, $valor);
        return $slider;
    }

}
