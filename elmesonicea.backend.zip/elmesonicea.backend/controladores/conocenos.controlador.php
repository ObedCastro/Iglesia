<?php

class ControladorConocenos {

    /* MOSTRAR INFORMACIÓN DE SLIDER */
   static public function ctrMostrarSliders($item, $valor){
        $tabla = "sliders";
        $slider = ModeloConocenos::mdlMostrarSliders($tabla, $item, $valor);
        return $slider;
    }

    /* GUARDAR SLIDER (NUEVO - EDITAR) */
    static public function ctrGuardarSlider($datos){
        $tabla = "sliders";
        $guardarSlider = ModeloConocenos::mdlGuardarSlider($tabla, $datos);

        if($guardarSlider == "insertado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Registro realizado exisosamente.");
        } else if($guardarSlider == "editado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "El registro se actualizó satisfactoriamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No ha sido posible realizar este registro \nPor favor compruebe la información.");
        }
    }
    
    /* ELIMINAR O DESACTIVAR SLIDER */
    static public function ctrEstadoSlider($item, $valor, $estado, $nEstado){
        $tabla = "sliders";
        $guardarSlider = ModeloConocenos::mdlEstadoSlider($tabla, $item, $valor, $estado, $nEstado);

        if($guardarSlider == "eliminado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Slider eliminado satisfactoriamente.");
        } else if($guardarSlider == "estadoActualizado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Estado de slider actualizado correctamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No fue posible cambiar el estado de este slider.".$guardarSlider);
        }
    }



    /* ============================================================== */


    /* MOSTRAR INFORMACIÓN DE SLIDER */
   static public function ctrMostrarFraseDinamica($item, $valor){
        $tabla = "frases_dinamicas";
        $frase = ModeloConocenos::mdlMostrarFraseDinamica($tabla, $item, $valor);
        return $frase;
    }
    
    static public function ctrGuardarContenidoDinamico($datos, $item, $valor){
        $tabla = "frases_dinamicas";
        $frase = ModeloConocenos::mdlGuardarContenidoDinamico($tabla, $datos, $item, $valor);
        
        if($frase == "ok"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Contenido dinámico modificado satisfactoriamente.");
        } else{
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "El contenido no se pudo modificar, intente nuevamente.");
        }
    
    
    }
    
    /* ================================================================================= */
    /* DECLARACIONES DE FE */
    /* ================================================================================= */
    
     /* MOSTRAR INFORMACIÓN DE DECLARACIÓN DE FE */
    static public function ctrMostrarDeclaraciones($item, $valor){
        $tabla = "declaraciones_de_fe";
        $declaraciones = ModeloConocenos::mdlMostrarDeclaraciones($tabla, $item, $valor);
        return $declaraciones;
    }

    /* INSERTAR O EDITAR NUEVA DECLARACIÓN DE FE */
    static public function ctrGuardarDeclaracionFe($datos){
        $tabla = "declaraciones_de_fe";
        $guardarDeclaracion = ModeloConocenos::mdlGuardarDeclaracionFe($tabla, $datos);
        
        if($guardarDeclaracion == "insertado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Registro realizado exisosamente.");
        } else if($guardarDeclaracion == "editado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "El registro se actualizó satisfactoriamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No ha sido posible realizar este registro \nPor favor compruebe la información.");
        }
    }

    /* ELIMINAR O DESACTIVAR DECLARACIÓN DE FE*/
    static public function ctrEstadoDeclaracion($item, $valor, $estado, $nEstado){
        $tabla = "declaraciones_de_fe";
        $estadoDeclaracion = ModeloConocenos::mdlEstadoDeclaracion($tabla, $item, $valor, $estado, $nEstado);

        if($estadoDeclaracion == "eliminado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Declaración de fe ha sido eliminada satisfactoriamente.");
        } else if($estadoDeclaracion == "estadoActualizado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Estado de esta declaración de fe, actualizado correctamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No fue posible cambiar el estado de esta declaración de fe, intente nuevamente.".$estadoDeclaracion);
        }
    }


    /* ================================================================================= */
    /* NUESTROS VALORES Y NUESTROS PILARES */
    /* ================================================================================= */
    
    /* MOSTRAR INFORMACIÓN DE NUESTROS VALORES Y NUESTROS PILARES */
    static public function ctrMostrarValoresPilares($item, $valor, $tipo){
        if($tipo == "valores"){
            $tabla = "nuestros_valores";
        } else if($tipo == "pilares"){
            $tabla = "nuestros_pilares";
        }
    
        $valores_pilares = ModeloConocenos::mdlMostrarValoresPilares($tabla, $item, $valor);
        return $valores_pilares;
    }

    /* INSERTAR O EDITAR NUESTROS VALORES O NUESTROS PILARES */
    static public function ctrGuardarValoresPilares($datos){
        if($datos["tipoVP"] == "valores"){
            $tabla = "nuestros_valores";
        } else if($datos["tipoVP"] == "pilares"){
            $tabla = "nuestros_pilares";
        }
        
        $guardarValoresPilares = ModeloConocenos::mdlGuardarValoresPilares($tabla, $datos);
        
        if($guardarValoresPilares == "insertado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Registro realizado exisosamente.");
        } else if($guardarValoresPilares == "editado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "El registro se actualizó satisfactoriamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No ha sido posible realizar este registro \nPor favor compruebe la información.");
        }
    }

     /* ELIMINAR O DESACTIVAR NUESTROS VALORES O NUESTROS PILARES */
    static public function ctrEstadoValoresPilares($item, $valor, $estado, $nEstado, $tipo){
        if($tipo == "valores"){
            $tabla = "nuestros_valores";
        } else if($tipo == "pilares"){
            $tabla = "nuestros_pilares";
        }

        $estadoValoresPilares = ModeloConocenos::mdlEstadoValoresPilares($tabla, $item, $valor, $estado, $nEstado);

        if($estadoValoresPilares == "eliminado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Item eliminado satisfactoriamente.");
        } else if($estadoValoresPilares == "estadoActualizado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Se actualizó el estado de este item.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No fue posible cambiar el estado de este item, intente nuevamente.".$estadoValoresPilares);
        }
    }

    /* ================================================================================= */
    /* COLABORADORES */
    /* ================================================================================= */
    
     /* MOSTRAR INFORMACIÓN DE COLABORADORES*/
    static public function ctrMostrarColaboradores($item, $valor){
        $tabla = "colaboradores";
        $colaboradores = ModeloConocenos::mdlMostrarColaboradores($tabla, $item, $valor);
        return $colaboradores;
    }

    /* INSERTAR O EDITAR COLABORADOR */
    static public function ctrGuardarColaborador($datos){
        $tabla = "colaboradores";
        $guardarColaborador = ModeloConocenos::mdlGuardarColaborador($tabla, $datos);
        
        if($guardarColaborador == "insertado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Registro realizado exisosamente.");
        } else if($guardarColaborador == "editado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "El registro se actualizó satisfactoriamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No ha sido posible realizar este registro \nPor favor compruebe la información.");
        }
    }

    /* ELIMINAR O DESACTIVAR COLABORADOR */
    static public function ctrEstadoColaborador($item, $valor, $estado, $nEstado){
        $tabla = "colaboradores";
        $estadoColaborador = ModeloConocenos::mdlEstadoColaborador($tabla, $item, $valor, $estado, $nEstado);

        if($estadoColaborador == "eliminado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Colaborador ha sido eliminado satisfactoriamente.");
        } else if($estadoColaborador == "estadoActualizado"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Estado del colaborador, actualizado correctamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No fue posible cambiar el estado de este colaborador, intente nuevamente.".$estadoColaborador);
        }
    }


}
