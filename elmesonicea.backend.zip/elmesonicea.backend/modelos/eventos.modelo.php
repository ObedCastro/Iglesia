<?php

require_once "conexion.php";

class ModeloEventos {

    static public function mdlCrearEvento($tabla, $datos) {

        $conexion = Conexion::conectar(); // Usar la misma conexión

        $stmt = $conexion->prepare(
            "INSERT INTO $tabla (titulo, descripcion, fecha, activo)
            VALUES (:titulo, :descripcion, :fecha, 1)"
        );

        $stmt->bindParam(":titulo", $datos["titulo"], PDO::PARAM_STR);
        $stmt->bindParam(":descripcion", $datos["descripcion"], PDO::PARAM_STR);
        $stmt->bindParam(":fecha", $datos["fecha"], PDO::PARAM_STR);

        if ($stmt->execute()) {
            return $conexion->lastInsertId(); // <-- Usar la misma conexión
        }

        return false;
    }



    static public function mdlGuardarImagen($tabla, $datos) {

        $stmt = Conexion::conectar()->prepare(
            "INSERT INTO $tabla (id_evento, imagen, titulo, descripcion)
             VALUES (:id_evento, :imagen, :titulo, :descripcion)"
        );

        $stmt->bindParam(":id_evento", $datos["id_evento"], PDO::PARAM_INT);
        $stmt->bindParam(":imagen", $datos["imagen"], PDO::PARAM_STR);
        $stmt->bindParam(":titulo", $datos["titulo"], PDO::PARAM_STR);
        $stmt->bindParam(":descripcion", $datos["descripcion"], PDO::PARAM_STR);

        return $stmt->execute();
    }


    /* MOSTRAR EVENTOS */
    public static function mdlMostrarEventos($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }


}
