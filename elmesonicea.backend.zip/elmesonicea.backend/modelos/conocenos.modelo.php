<?php

require_once "conexion.php";

class ModeloConocenos {

    /* MOSTRAR SLIDER O SLIDERS */
    public static function mdlMostrarSliders($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }

    /* GUARDAR SLIDER (NUEVO - EDITAR) */
    static public function mdlGuardarSlider($tabla, $datos){
        if (!empty($datos["id"])) {
            try{
                if(!empty($datos["imagen"])){
                    $sql = "UPDATE $tabla SET f_principal = :f_principal, f_superior = :f_superior, f_inferior = :f_inferior, img_fondo = :img_fondo WHERE id = :id";
                } else{
                    $sql = "UPDATE $tabla SET f_principal = :f_principal, f_superior = :f_superior, f_inferior = :f_inferior WHERE id = :id";
                }
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":f_principal", $datos["f_principal"], PDO::PARAM_STR);
                $stmt->bindParam(":f_superior", $datos["f_superior"], PDO::PARAM_STR);
                $stmt->bindParam(":f_inferior", $datos["f_inferior"], PDO::PARAM_STR);

                if (!empty($datos["imagen"])){
                    $stmt->bindParam(":img_fondo", $datos["imagen"], PDO::PARAM_STR);
                }

                $stmt->bindParam(":id", $datos["id"], PDO::PARAM_INT);

                if($stmt->execute()){
                    return "editado";
                }

                return "No se pudo completar la edición";

            } catch(PDOException $e){
                return "Error de BD: " . $e->getMessage();
            } finally {
                $stmt = null;
            }
        } else{

            try {
                $sql = "INSERT INTO $tabla (f_principal, f_superior, f_inferior, img_fondo) VALUES (?, ?, ?, ?)";
                $stmt = Conexion::conectar()->prepare($sql);
                $insertar = $stmt->execute([
                    $datos["f_principal"],
                    $datos["f_superior"],
                    $datos["f_inferior"],
                    $datos["imagen"]
                ]);

                if($insertar){
                    return "insertado";
                }

                return "No se pudo completar el registro";
                
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }
    }

    /* ELIMINAR O DESACTIVAR SLIDER */
    static public function mdlEstadoSlider($tabla, $item, $valor, $estado, $nEstado){
        if($estado == "eliminarSlider"){
            try{
                $sql = "DELETE FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        
                if($stmt->execute()){
                    return "eliminado";
                }
            } catch(PDOException $e){
                return "error: ".$e->getMessage();
            }

        } else if($estado == "estadoSlider"){
            try{
                $sql = "UPDATE $tabla SET activo = :activo WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":activo", $nEstado, PDO::PARAM_INT);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_INT);

                if($stmt->execute()){
                    return "estadoActualizado";
                }

            } catch(PDOException $e){
                return "error: ".$e->getMessage();
            }
        }
    }



    /* ================================================================== */



    static public function mdlMostrarFraseDinamica($tabla, $item, $valor){
        if($item != null){
            $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        } else{
            $sql = "SELECT * FROM $tabla";
        }

        try{
            $stmt = Conexion::conectar()->prepare($sql);

            if($item != null){
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_INT);
            }

            $stmt->execute();
    
            return $stmt->fetch();
        } catch (PDOException $e){
            return "Error de BD: ".$e->getMessage();
        }
    }

    static public function mdlGuardarContenidoDinamico($tabla, $datos, $item, $valor){
        $sql = "UPDATE $tabla SET frase_estatica = :frase_estatica, frases_dinamicas = :frases_dinamicas, activo = :activo WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":frase_estatica", $datos["frase_estatica"], PDO::PARAM_STR);
        $stmt->bindParam(":frases_dinamicas", $datos["frase_dinamica"], PDO::PARAM_STR);
        $stmt->bindParam(":activo", $datos["activo"], PDO::PARAM_INT);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_INT);

        if($stmt->execute()){
            return "ok";
        }
    }


    
    /* ================================================================================= */
    /* DECLARACIONES DE FE */
    /* ================================================================================= */
    
    /* MOSTRAR DECLARACIONES DE FE */
    public static function mdlMostrarDeclaraciones($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }

    /* AGREGAR O EDITAR DECLARACIÓN DE FE */
    static public function mdlGuardarDeclaracionFe($tabla, $datos){
        if (!empty($datos["id"])) {
            try{
                $sql = "UPDATE $tabla SET numero = :numero, titulo = :titulo, descripcion = :descripcion, versiculo = :versiculo WHERE id = :id";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":numero", $datos["numero"], PDO::PARAM_STR);
                $stmt->bindParam(":titulo", $datos["titulo"], PDO::PARAM_STR);
                $stmt->bindParam(":descripcion", $datos["descripcion"], PDO::PARAM_STR);
                $stmt->bindParam(":versiculo", $datos["versiculo"], PDO::PARAM_STR);
                $stmt->bindParam(":id", $datos["id"], PDO::PARAM_INT);

                if($stmt->execute()){
                    return "editado";
                }

                return "No se pudo completar la edición";

            } catch(PDOException $e){
                return "Error de BD: " . $e->getMessage();
            } finally {
                $stmt = null;
            }
        } else{

            try {
                $sql = "INSERT INTO $tabla (numero, titulo, descripcion, versiculo) VALUES (?, ?, ?, ?)";
                $stmt = Conexion::conectar()->prepare($sql);
                $insertar = $stmt->execute([
                    $datos["numero"],
                    $datos["titulo"],
                    $datos["descripcion"],
                    $datos["versiculo"]
                ]);

                if($insertar){
                    return "insertado";
                }

                return "No se pudo completar el registro";
                
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }
    }

    /* ELIMINAR O DESACTIVAR DECLARACIÓN DE FE */
    static public function mdlEstadoDeclaracion($tabla, $item, $valor, $estado, $nEstado){
        if($estado == "eliminarDeclaracion"){
            try{
                $sql = "DELETE FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        
                if($stmt->execute()){
                    return "eliminado";
                }
            } catch(PDOException $e){
                return "error: ".$e->getMessage();
            }

        } else if($estado == "estadoDeclaracion"){
            try{
                $sql = "UPDATE $tabla SET activo = :activo WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":activo", $nEstado, PDO::PARAM_INT);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_INT);

                if($stmt->execute()){
                    return "estadoActualizado";
                }

            } catch(PDOException $e){
                return "error: ".$e->getMessage();
            }
        }
    }


    /* ================================================================================= */
    /* NUESTROS VALORES Y NUESTROS PILARES */
    /* ================================================================================= */
    
    /* MOSTRAR NUESTROS VALORES Y NUESTROS PILARES */
    public static function mdlMostrarValoresPilares($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }

    /* AGREGAR O EDITAR NUESTROS VALORES O NUESTROS PILARES */
    static public function mdlGuardarValoresPilares($tabla, $datos){
        if (!empty($datos["id"])) {
            try{
                $sql = "UPDATE $tabla SET titulo = :titulo, descripcion = :descripcion WHERE id = :id";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":titulo", $datos["titulo"], PDO::PARAM_STR);
                $stmt->bindParam(":descripcion", $datos["descripcion"], PDO::PARAM_STR);
                $stmt->bindParam(":id", $datos["id"], PDO::PARAM_INT);

                if($stmt->execute()){
                    return "editado";
                }

                return "No se pudo completar la edición";

            } catch(PDOException $e){
                return "Error de BD: " . $e->getMessage();
            } finally {
                $stmt = null;
            }
        } else{

            try {
                $sql = "INSERT INTO $tabla (titulo, descripcion) VALUES (?, ?)";
                $stmt = Conexion::conectar()->prepare($sql);
                $insertar = $stmt->execute([
                    $datos["titulo"],
                    $datos["descripcion"]
                ]);

                if($insertar){
                    return "insertado";
                }

                return "No se pudo completar el registro";
                
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }
    }

    /* ELIMINAR O DESACTIVAR VALORES O PILARES */
    static public function mdlEstadoValoresPilares($tabla, $item, $valor, $estado, $nEstado){
        if($estado == "eliminarValoresPilares"){
            try{
                $sql = "DELETE FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        
                if($stmt->execute()){
                    return "eliminado";
                }
            } catch(PDOException $e){
                return "error: ".$e->getMessage();
            }

        } else if($estado == "estadoValoresPilares"){
            try{
                $sql = "UPDATE $tabla SET activo = :activo WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":activo", $nEstado, PDO::PARAM_INT);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_INT);

                if($stmt->execute()){
                    return "estadoActualizado";
                }

            } catch(PDOException $e){
                return "error: ".$e->getMessage();
            }
        }
    }

    /* ================================================================================= */
    /* COLABORADORES */
    /* ================================================================================= */
    
    /* MOSTRAR COLABORADORES */
    public static function mdlMostrarColaboradores($tabla, $item, $valor){
        if($item != null){
            try{
                $sql = "SELECT * FROM $tabla WHERE $item = :$item";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
                $stmt->execute();
    
                return $stmt->fetch();
            } catch (PDOException $e) {
                return $e->getMessage();
            }

        } else{
            $sql = "SELECT * FROM $tabla";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();
    
            return $stmt->fetchAll();
        }
    }

    /* AGREGAR O EDITAR COLABORADORES */
    static public function mdlGuardarColaborador($tabla, $datos){
        if (!empty($datos["id"])) {
            try{
                $sql = "UPDATE $tabla SET nombre = :nombre, cargo = :cargo, descripcion = :descripcion, telefono = :telefono, foto_perfil = :foto_perfil WHERE id = :id";
                $stmt = Conexion::conectar()->prepare($sql);
                $stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
                $stmt->bindParam(":cargo", $datos["cargo"], PDO::PARAM_STR);
                $stmt->bindParam(":descripcion", $datos["descripcion"], PDO::PARAM_STR);
                $stmt->bindParam(":telefono", $datos["telefono"], PDO::PARAM_STR);
                $stmt->bindParam(":foto_perfil", $datos["foto_perfil"], PDO::PARAM_STR);
                $stmt->bindParam(":id", $datos["id"], PDO::PARAM_INT);

                if($stmt->execute()){
                    return "editado";
                }

                return "No se pudo completar la edición";

            } catch(PDOException $e){
                return "Error de BD: " . $e->getMessage();
            } finally {
                $stmt = null;
            }
        } else{

            try {
                $sql = "INSERT INTO $tabla (nombre, cargo, descripcion, telefono, foto_perfil) VALUES (?, ?, ?, ?, ?)";
                $stmt = Conexion::conectar()->prepare($sql);
                $insertar = $stmt->execute([
                    $datos["nombre"],
                    $datos["cargo"],
                    $datos["descripcion"],
                    $datos["telefono"],
                    $datos["foto_perfil"]
                ]);

                if($insertar){
                    return "insertado";
                }

                return "No se pudo completar el registro";
                
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }
    }

    
}

