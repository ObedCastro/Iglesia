<?php

require_once "conexion.php";

class ModeloUsuarios{

    /* INICIAR SESIÓN */
    static public function mdlIngresarUsuarios($tabla, $item, $valor){
        $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch();

        $stmt->close();
        $stmt = null;

    }

    /* LISTAR USUARIOS */
    static public function mdlMostrarUsuarios($tabla, $item, $valor){
      if($item != null){
        $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch();

      } else{
        $sql = "SELECT * FROM $tabla";
        $stmt = Conexion::conectar()->prepare($sql);

        if($stmt->execute()){
          return $stmt->fetchAll();
        } else{
            return array("Error" => "No ha sido posible obtener la información");
        }
      }
    }

}