<?php

require_once "conexion.php";

class ModeloUsuarios{

    /* INICIAR SESIÓN */
    static public function mdlIngresarUsuarios($tabla, $item, $valor){
        $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch();

        $stmt->close();
        $stmt = null;

    }

    /* LISTAR USUARIOS */
    static public function mdlMostrarUsuarios($tabla, $item, $valor){
      if($item != null){
        $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch();

      } else{
        $sql = "SELECT * FROM $tabla";
        $stmt = Conexion::conectar()->prepare($sql);

        if($stmt->execute()){
          return $stmt->fetchAll();
        } else{
            return array("Error" => "No ha sido posible obtener la información");
        }
      }
    }

    /* CAMBIAR FOTO DE PERFIL DEL USUARIO */
    static public function mdlCambiarFotoUsuario($tabla, $nombreImgGuardar, $idUsuario){
    try{
      $sql = "UPDATE $tabla SET foto=:foto WHERE id = :id";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->bindParam(":foto", $nombreImgGuardar, PDO::PARAM_STR);
      $stmt->bindParam(":id", $idUsuario, PDO::PARAM_STR);
      
      if($stmt->execute()){
        return "ok";
      }

    } catch(PDOException $e){
      return $e->getMessage();
    }
  }

  /* CAMBIAR CONTRASEÑA DE USUARIO */
  static public function mdlCambiarPasswordUsuario($tabla, $item, $valor, $pass){
      try{
        $sql = "UPDATE $tabla SET password = :password WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":password", $pass, PDO::PARAM_STR);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        
        if($stmt->execute()){
          return "ok";
        }

      } catch(PDOException $e){
        return $e->getMessage();
      }
    }

}