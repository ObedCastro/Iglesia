<?php

require_once "../controladores/conocenos.controlador.php";
require_once "../modelos/conocenos.modelo.php";

class AjaxConocenos{
    public $idSlider;
    public $datosSlider;
    public $estadoSlider;
    public $nuevoEstado;
    public $idFraseDinamica;

    public $idDeclaracion;
    public $datosDeclaracion;
    public $estadoDeclaracion;

    /* ==================================================== */
    /* SLIDERS */
    /* ==================================================== */

    /* MOSTRAR INFO PARA EDITAR SLIDER */
    public function infoEditarSlider(){
        $item = "id";
        $valor = $this->idSlider;

        $respuesta = ControladorConocenos::ctrMostrarSliders($item, $valor);

        echo json_encode($respuesta);
    }

    /* EDITAR o AGREGAR SLIDER */
    public function ajaxGuardarSlider() {
        $datos = $this->datosSlider;

        if (isset($_FILES["imgSlider"]) && $_FILES["imgSlider"]["error"] == 0) {

            $ruta = $_SERVER['DOCUMENT_ROOT']."/elmesonicea.backend/vistas/assets/img/sliders/";
            $nombre = uniqid() . "_" . $_FILES["imgSlider"]["name"];
            $rutaFinal = $ruta . $nombre;

            $tipo = $_FILES["imgSlider"]["type"];
            if ($tipo != "image/jpeg" && $tipo != "image/png") {
                echo json_encode([
                    "error" => "Formato de imagen no permitido"
                ]);
                return;
            }

            move_uploaded_file($_FILES["imgSlider"]["tmp_name"], $rutaFinal);

            $datos["imagen"] = $nombre;

        } else {
            $datos["imagen"] = null;
        }

        $respuesta = ControladorConocenos::ctrGuardarSlider($datos);

        echo json_encode($respuesta);
    }

    /* ELIMINAR O DESACTIVAR SLIDER */
    public function estadoSlider(){
        $item = "id";
        $valor = $this->idSlider;
        $estado = $this->estadoSlider;
        $nEstado = $this->nuevoEstado;

        $respuesta = ControladorConocenos::ctrEstadoSlider($item, $valor, $estado, $nEstado);

        echo json_encode($respuesta);
    }


    /* ==================================================== */
    /* FRASE DINÁMICA */
    /* ==================================================== */

    /* MOSTRAR INFORMACIÓN DE LA FRASE DINÁMICA */
    public function infoFraseDinamica(){
        $item = "id";
        $valor = $this->idFraseDinamica;

        $respuesta = ControladorConocenos::ctrMostrarFraseDinamica($item, $valor);

        echo json_encode($respuesta);
    }
    
    /* MODIFICAR FRASE DINÁMICA */
    public function guardarContenidoDinamico(){
        $item = "id";
        $valor = $this->idFraseDinamica;

        $datos = [
            "frase_estatica" => $_POST["frase_estatica"],
            "frase_dinamica" => $_POST["frase_dinamica"],
            "activo" => $_POST["estadoFrase"]
        ];

        $respuesta = ControladorConocenos::ctrGuardarContenidoDinamico($datos, $item, $valor);

        echo json_encode($respuesta);
    }


    /* ==================================================== */
    /* DECLARACIÓND DE FE */
    /* ==================================================== */

    public function infoEditarDeclaracion(){
        $item = "id";
        $valor = $this->idDeclaracion;

        $respuesta = ControladorConocenos::ctrMostrarDeclaraciones($item, $valor);

        echo json_encode($respuesta);
    }

    public function ajaxGuardarDeclaracionFe() {
        $datos = $this->datosDeclaracion;

        $respuesta = ControladorConocenos::ctrGuardarDeclaracionFe($datos);

        echo json_encode($respuesta);
    }

    public function estadoDeclaracion(){
        $item = "id";
        $valor = $this->idDeclaracion;
        $estado = $this->estadoDeclaracion;
        $nEstado = $this->nuevoEstado;

        $respuesta = ControladorConocenos::ctrEstadoDeclaracion($item, $valor, $estado, $nEstado);

        echo json_encode($respuesta);
    }


}







/* ==================== SLIDER ==================== */

if(isset($_POST["accion"]) && $_POST["accion"] == "traerSlider"){
    $editar = new AjaxConocenos();
    $editar->idSlider = $_POST["idSlider"];
    $editar->infoEditarSlider();
}

if(isset($_POST["accion"]) && ($_POST["accion"] == "estadoSlider" || $_POST["accion"] == "eliminarSlider")){
    $editar = new AjaxConocenos();
    $editar->idSlider = $_POST["idSlider"];
    $editar->estadoSlider = $_POST["accion"];
    $editar->nuevoEstado = $_POST["nuevoEstado"] ?? null;    
    $editar->estadoSlider();
}

if(isset($_POST["f_principal"]) && $_POST["accion"] == "guardarSlider"){
    $guardar = new AjaxConocenos();
    $guardar -> datosSlider = array(
        "id" => $_POST["idSlider"],
        "f_principal" => $_POST["f_principal"],
        "f_superior" => $_POST["f_superior"],
        "f_inferior" => $_POST["f_inferior"]
    );
    
    $guardar -> ajaxGuardarSlider();
}


/* ==================== SLIDER ==================== */

if(isset($_POST["accion"]) && $_POST["accion"] == "traerFraseDinamica"){
    $frase = new AjaxConocenos();
    $frase->idFraseDinamica = $_POST["idFraseDinamica"];
    $frase->infoFraseDinamica();
}

if(isset($_POST["accion"]) && $_POST["accion"] == "modificarFraseDinamica"){
    $frase = new AjaxConocenos();
    $frase->idFraseDinamica = $_POST["idFrase"];
    $frase->guardarContenidoDinamico();
}


/* ==================== DECLRACIÓN DE FE ==================== */

if(isset($_POST["accion"]) && $_POST["accion"] == "traerDeclaracion"){
    $editarDeclaracion = new AjaxConocenos();
    $editarDeclaracion->idDeclaracion = $_POST["idDeclaracion"];
    $editarDeclaracion->infoEditarDeclaracion();
}

if(isset($_POST["accion"]) && $_POST["accion"] == "guardarDeclaracion"){
    $declaracion = new AjaxConocenos();
    $declaracion->datosDeclaracion = array(
        "id" => $_POST["idDeclaracion"],
        "numero" => $_POST["numero_declaracion"],
        "titulo" => $_POST["tituloDeclaracion"],
        "descripcion" => $_POST["descripcionDeclaracion"],
        "versiculo" => $_POST["versiculoDeclaracion"]
    );
    $declaracion->ajaxGuardarDeclaracionFe();
}

if(isset($_POST["accion"]) && ($_POST["accion"] == "estadoDeclaracion" || $_POST["accion"] == "eliminarDeclaracion")){
    $editar = new AjaxConocenos();
    $editar->idDeclaracion = $_POST["idDeclaracion"];
    $editar->estadoDeclaracion = $_POST["accion"];
    $editar->nuevoEstado = $_POST["nuevoEstado"] ?? null;    
    $editar->estadoDeclaracion();
}