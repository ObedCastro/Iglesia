<?php

require_once "../controladores/conocenos.controlador.php";
require_once "../modelos/conocenos.modelo.php";
// Aquí puedes agregar más controladores según necesites
// require_once "../controladores/usuarios.controlador.php"; 

class AjaxTablas {

    public function mostrarTablas() {

        if($_GET["tipoTabla"] == "sliders") {
            
            $item = null;
            $valor = null;
            $respuesta = ControladorConocenos::ctrMostrarSliders($item, $valor);
            
            echo json_encode(array("data" => $respuesta));
            
        } else if($_GET["tipoTabla"] == "declaraciones"){

            $item = null;
            $valor = null;
            $respuesta = ControladorConocenos::ctrMostrarDeclaraciones($item, $valor);
            echo json_encode(array("data" => $respuesta));

        } else if($_GET["tipoTabla"] == "valores" || $_GET["tipoTabla"] == "pilares"){

            $item = null;
            $valor = null;
            $tipo = $_GET["tipoTabla"];
            $respuesta = ControladorConocenos::ctrMostrarValoresPilares($item, $valor, $tipo);
            echo json_encode(array("data" => $respuesta));

        } else if($_GET["tipoTabla"] == "colaboradores"){

            $item = null;
            $valor = null;
            $respuesta = ControladorConocenos::ctrMostrarColaboradores($item, $valor);
            echo json_encode(array("data" => $respuesta));

        }
        /* else if ($_GET["tipoTabla"] == "usuarios") {
            // Lógica para otra tabla...
        } 
        */
    }
}

if(isset($_GET["tipoTabla"])){
    $activarTabla = new AjaxTablas();
    $activarTabla -> mostrarTablas();
}