<?php

session_start();

require_once "../controladores/usuarios.controlador.php";
require_once "../modelos/usuarios.modelo.php";

class AjaxUsuarios{

    /* CAMBIAR FOTO DE PERFIL DEL USUARIO */
    public function ajaxCambiarFotoUsuario(){
        $usuario = $_SESSION["usuario"];
        $ruta = $_SERVER['DOCUMENT_ROOT']."/elmesonicea.backend/vistas/assets/img/usuarios/";

        if(isset($_FILES["imagenPerfil"]["name"])){
          $imageName = $_FILES['imagenPerfil']['name'];
          $tmpName = $_FILES['imagenPerfil']['tmp_name'];  
          
          $nombreImagen = pathinfo($imageName, PATHINFO_FILENAME);
          $extension = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
      
          $nombreImgGuardar = $usuario.'-'.time().'.'.$extension;
          $target_file = $ruta.$nombreImgGuardar;
          $idUsuario = $_SESSION["id"];
      
          if (file_exists($target_file)) {
              unlink($target_file);
          }
      
          if (move_uploaded_file($tmpName, $target_file)) {
              $respuesta = ControladorUsuarios::ctrCambiarFotoPerfilUsuario($nombreImgGuardar, $idUsuario);
              echo json_encode($respuesta);
          }
    
        }else {
            echo json_encode($respuesta);
        }
    }
    
    /* CAMBIAR CONTRASEÑA DE USUARIO */
    public function ajaxCambiarPasswordUsuario(){
        $item = "id";
        $valor = $_POST["idAdmin"];
    
        $anteriorPassword = $_POST["anteriorPassword"];
        $nuevaPassword = $_POST["nuevaPassword"];
    
        $passwordActual = ControladorUsuarios::ctrMostrarUsuarios($item, $valor);
    
        if($passwordActual["password"] == md5($anteriorPassword)){
          $pass = md5($nuevaPassword); 
    
          $actualizar = ControladorUsuarios::ctrCambiarPasswordUsuario($item, $valor, $pass);
    
          echo json_encode($actualizar);
    
        } else{
          echo json_encode(array("mensaje" => "Contraseña anterior no válida", "error" => "Contraseña anterior no válida"));
        }
    }
}



/* ================================================================================== */

/* CAMBIAR FOTO DE PERFIL DE USUARIO */
if(isset($_FILES['imagenPerfil'])){
  $nuevaFotoPerfil = new AjaxUsuarios();
  $nuevaFotoPerfil->ajaxCambiarFotoUsuario();
}

/* CAMBIAR CONTRASEÑA DE USUARIO */
if(isset($_POST["nuevaPassword"])){
  $cambiarPassword = new AjaxUsuarios();
  $cambiarPassword->ajaxCambiarPasswordUsuario();
}