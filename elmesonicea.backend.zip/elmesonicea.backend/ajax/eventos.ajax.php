<?php

require_once "../controladores/eventos.controlador.php";
require_once "../modelos/eventos.modelo.php";

class AjaxEventos {

    public function ajaxGuardarEvento() {

        $datosEvento = [
            "titulo" => $_POST["tituloEvento"],
            "descripcion" => $_POST["descripcionEvento"],
            "fecha" => $_POST["fechaEvento"]
        ];

        $imagenes = $_FILES["imagenes"];
        $titulos = $_POST["titulosImagen"];
        $descripciones = $_POST["descripcionesImagen"];

        $respuesta = ControladorEventos::ctrGuardarEvento(
            $datosEvento,
            $imagenes,
            $titulos,
            $descripciones
        );

        echo json_encode($respuesta);
    }
}

if (isset($_POST["accion"]) && $_POST["accion"] == "guardarEvento") {
    $evento = new AjaxEventos();
    $evento->ajaxGuardarEvento();
}
