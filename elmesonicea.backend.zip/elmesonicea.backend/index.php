<?php

/* CONTROLADORES */
require_once "controladores/base.controlador.php";
require_once "controladores/usuarios.controlador.php";
require_once "controladores/conocenos.controlador.php";

/* MODELOS */
require_once "modelos/rutas.php";
require_once "modelos/usuarios.modelo.php";
require_once "modelos/conocenos.modelo.php";



/* Llamando a la plantilla base */
$base = new ControladorBase();
$base->base();