<?php 
  session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="vistas/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="vistas/assets/img/favicon.png">
  <title>
    ADMIN | El mesón ICEA
  </title>

  <!-- Para mostrar la ruta estática -->
  <?php
      $url = Rutas::mdlRuta(); 
  ?>

  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,800" rel="stylesheet" />

  <!-- Nucleo Icons -->
  <link href="https://demos.creative-tim.com/soft-ui-dashboard/assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="https://demos.creative-tim.com/soft-ui-dashboard/assets/css/nucleo-svg.css" rel="stylesheet" />

  <!-- Datatables -->
   <link rel="stylesheet" href="https://cdn.datatables.net/2.3.6/css/dataTables.dataTables.css" />

  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/21896480bc.js" crossorigin="anonymous"></script>

  <!-- CSS Files -->
  <link href="vistas/assets/css/soft-ui-dashboard.css?v=1.1.0" rel="stylesheet" />
  <link href="<?php echo $url ?>vistas/assets/css/sweetalert2.min.css" rel="stylesheet" />

  <!-- CSS PERSONALIZADO -->
   <link rel="stylesheet" href="<?php echo $url; ?>vistas/css/gestorNavbar.css">
   <link rel="stylesheet" href="<?php echo $url; ?>vistas/css/conocenos.css">
  
  <!-- Nepcha is a easy-to-use web analytics. No cookies and fully compliant with GDPR, CCPA and PECR. -->
  <script defer data-site="YOUR_DOMAIN_HERE" src="https://api.nepcha.com/js/nepcha-analytics.js"></script>   

</head>
<body class="g-sidenav-show  bg-gray-100">

  <script>
    var localhost = "http://localhost/elmesonicea.backend/";
  </script>
  
  <?php

    if(isset($_SESSION["validarSesion"]) && $_SESSION["validarSesion"] == "ok"){

      include "modulos/aside.php";

      echo '<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">';

        include "modulos/navbar.php";

        $ruta = explode("/", $_GET["ruta"]);

        if(isset($ruta[0])){
          if($ruta[0] == "conocenos" ||
             $ruta[0] == "fe" ||
             $ruta[0] == "valores-y-pilares" ||
             $ruta[0] == "colaboradores" ||
             $ruta[0] == "salir"){
            include "modulos/".$ruta[0].".php";
          }
        }

        include "modulos/footer.php";

      echo '</main>';
    } else{
      include "modulos/login.php";
    }

  ?>
  

  <!-- ======================================================================================= -->

  <script src="<?php echo $url; ?>vistas/assets/js/jquery-3.7.1.min.js"></script>
  <script src="<?php echo $url; ?>vistas/assets/js/core/popper.min.js"></script>
  <script src="<?php echo $url; ?>vistas/assets/js/core/bootstrap.min.js"></script>
  <script src="<?php echo $url; ?>vistas/assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="<?php echo $url; ?>vistas/assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="<?php echo $url; ?>vistas/assets/js/plugins/chartjs.min.js"></script>
  <script src="<?php echo $url; ?>vistas/assets/js/sweetalert2.all.min.js"></script>
  <script src="https://cdn.datatables.net/2.3.6/js/dataTables.js"></script>

    <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>

  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo $url; ?>vistas/assets/js/soft-ui-dashboard.min.js?v=1.1.0"></script>

  <!-- JS PERSONALIZADO -->
   <script src="<?php echo $url; ?>vistas/js/navbar.js"></script>
   <script src="<?php echo $url; ?>vistas/js/usuarios.js"></script>
   <script src="<?php echo $url; ?>vistas/js/tabla.js"></script>
   <script src="<?php echo $url; ?>vistas/js/conocenos.js"></script>
    
</body>
</html>