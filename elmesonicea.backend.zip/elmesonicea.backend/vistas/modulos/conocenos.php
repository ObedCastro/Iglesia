<?php

echo '<div class="container-fluid py-2">';

    include "conocenos/conocenos.php";

echo '</div>';