<?php

echo '<div class="py-2">';

    include "conocenos/conocenos.php";

echo '</div>';