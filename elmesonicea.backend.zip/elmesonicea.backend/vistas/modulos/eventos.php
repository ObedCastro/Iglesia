<div class="container">
  <div class="row">
    <div class="col-12">
        <div class="card mb-4">
        <div class="card-header pb-0 d-flex justify-content-between">
            <h6>Declaración de fe</h6>
            <div class="d-flex">
  
            <button type="button" class="btn btn-primary" id="btnNuevoEvento" data-bs-toggle="modal" data-bs-target="#modalEventos">
              <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
              Añadir
            </button>
            </div>
        </div>
  
        <div class="card-body px-0 pt-0 pb-2 min-vh-25">
            <div class="table-responsive px-4">
              <table id="datatableEventos" class="table align-items-center mb-0 display">
                  <thead>
                  <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Evento</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Descripción</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Fecha</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Activo</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">opciones</th>
                  </tr>
                  </thead>
    
                  <!--<tbody>
                  </tbody>-->
    
              </table>
            </div>
        </div>
        </div>
    </div>
  </div> 
</div>


<!-- ========================================================================== -->

<!-- MODAL PARA CREAR NUEVA DECLARACIÓN DE FE -->
<div class="modal fade" id="modalEventos" data-bs-backdrop="static" tabindex="-1" aria-labelledby="modalEventosLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <h1 class="modal-title fs-5 text-white"><i class="fa fa-copy"></i><span id="modalEventosLabel"></span></h1>
      </div>
      <div class="modal-body">
        <span class="text-secondary text-xxs">Los campos con <span class="text-danger">*</span> son obligatorios.</span>
        <!-- <form action="" method="post" class="needs-validation" id="formDeclaracion" novalidate>
          <input type="hidden" name="idDeclaracion" id="idDeclaracion">

          <div class="mb-3 row">
            <div class="col-md-6">
              <label for="numero_declaracion" class="form-label">Número <span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Ingrese una Número" id="numero_declaracion" name="numero_declaracion" minlength="1" maxlength="5" required>
              <div class="invalid-feedback"></div>
            </div>

            <div class="col-md-6">
              <label for="tituloDeclaracion" class="form-label">Título <span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Ingrese la Título" id="tituloDeclaracion" name="tituloDeclaracion" minlength="5" maxlength="100" required>
              <div class="invalid-feedback">El título es requerido.</div>
            </div>
          </div>

          <div class="mb-3 row">
            <div class="col-md-6">
              <label for="descripcionDeclaracion" class="form-label">Descripción <span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Ingrese la Descripción" id="descripcionDeclaracion" name="descripcionDeclaracion" minlength="10" maxlength="100" required>
              <div class="invalid-feedback">La Descripción es requerida.</div>
            </div>
            
            <div class="col-md-6">
              <label for="versiculoDeclaracion" class="form-label">Versículo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Ingrese la Versículo" id="versiculoDeclaracion" name="versiculoDeclaracion" minlength="10" maxlength="50" required>
              <div class="invalid-feedback">El versículo es requerido.</div>
            </div>

          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary">Guardar</button>
          </div>
        </form> -->

        <div class="container mt-4">
            <form id="formEvento" enctype="multipart/form-data">

                <!-- EVENTO -->
                <div class="mb-3">
                    <label class="form-label">Título del evento</label>
                    <input type="text" name="tituloEvento" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Descripción</label>
                    <textarea name="descripcionEvento" class="form-control" rows="3" required></textarea>
                </div>

                <div class="mb-4">
                    <label class="form-label">Fecha</label>
                    <input type="date" name="fechaEvento" class="form-control" required>
                </div>

                <hr>

                <!-- GALERÍA -->
                <h6>Galería del evento</h6>

                <div id="contenedorImagenes">
                    <div class="row imagen-item mb-3">
                        <div class="col-md-4">
                            <input type="file" name="imagenes[]" class="form-control" accept="image/jpeg,image/png" required>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="titulosImagen[]" class="form-control" placeholder="Título imagen" required>
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="descripcionesImagen[]" class="form-control" placeholder="Descripción imagen" required>
                        </div>
                    </div>
                </div>

                <button type="button" id="btnAgregarImagen" class="btn btn-secondary mb-3">
                    ➕ Agregar imagen
                </button>

                <div class="text-end">
                    <button type="submit" class="btn btn-primary">
                        Guardar evento
                    </button>
                </div>

            </form>
        </div>


      </div>
    </div>
  </div>
</div>
