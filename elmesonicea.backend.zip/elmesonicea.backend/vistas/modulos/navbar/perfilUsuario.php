<div>
  <div class="preview text-center">
    <?php
      echo '<img class="perfil-photo card-img-top" src="'.$url.'vistas/assets/img/usuarios/'.$admin["foto"].'" alt="...">';
    ?>

    <p>
      <i class="fa fa-pencil cursor-pointer" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
      </i>
    </p>
    <div>
      <div class="collapse collapse-horizontal" id="collapseWidthExample">
        <div class="card card-body bg-secondary">
          <form id="cargarImagen" enctype="multipart/form-data">
              <div class="mb-3">
                  <label for="imagenPerfil" class="form-label">Selecciona una imagen</label>
                  <input class="form-control" type="file" id="imagenPerfil" name="imagenPerfil" accept=".jpg" required>
              </div>
              <button type="submit" class="btn btn-primary">Cargar</button>
          </form>
        </div>
      </div>
    </div>


  </div>
  
    <h6 class="card-title mb-0"><?php echo $_SESSION['nombre']; ?></h6>
    <p class="card-title text-bold"><?php echo $_SESSION['correo']; ?></p>
    <p class="text-xs mb-2"><strong>Cargo:</strong> <?php echo $_SESSION['cargo']; ?></p>
 
    <div class="accordion" id="accordionPassword">
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingOne">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Cambiar mi contraseña
          </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse cambiarPassword" aria-labelledby="headingOne" data-bs-parent="#accordionPassword">
          <form method="post" id="formCambioPassword">
            <input type="hidden" name="idAdmin" value="<?php echo $_SESSION["id"]; ?>">
            <div>
              <label for="anteriorPassword" class="form-label">Contraseña anterior</label>
              <input type="password" class="form-control" placeholder="Contraseña anterior" id="anteriorPassword" name="anteriorPassword">
            </div>
            <div>
              <label for="nuevaPassword" class="form-label">Nueva contraseña</label>
              <input type="password" class="form-control" placeholder="Nueva contraseña" id="nuevaPassword" name="nuevaPassword">
            </div>
            <div>
              <label for="repetirPassword" class="form-label">Repetir nueva contraseña</label>
              <input type="password" class="form-control" placeholder="Repetir contraseña" id="repetirPassword">
            </div>

            <p class="text-danger text-xxs mensajeError"></p>

            <div class="text-center mt-2">
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </form>

          <!-- CONTENIDO QUE NO SE MEUSTRA -->
          <div class="d-none">
            <button class="btn bg-gradient-primary w-100 px-3 mb-2 active disabled" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
            <button class="btn bg-gradient-primary w-100 px-3 mb-2 ms-2 disabled" data-class="bg-white" onclick="sidebarType(this)">White</button>
            </div>
          <div class="d-none form-check form-switch ps-0">
            <input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)" checked="true">
          </div>

        </div>
      </div>
    </div>

  <div class="text-center pt-2">
    <a href="#" id="btnSalir" class=" btn btn-outline-danger">Cerrar sesión</a>
  </div>
</div>
 
<script>
  document.getElementById('btnSalir').href = localhost+"salir";
</script>