<div class="container">
  <div class="row">
    <div class="col-12">
        <div class="card mb-4">
        <div class="card-header pb-0 d-flex justify-content-between">
            <h6>Colaboradores</h6>
            <div class="d-flex">
            <!-- Button trigger modal -->
            <!-- <button type="button" class="btn btn-outline-primary mx-2" id="btnContenidoDinamico" data-bs-toggle="modal" data-bs-target="#modalContenidoDinamico">
              <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
              Frase dinámica
            </button> -->
  
            <button type="button" class="btn btn-primary" id="btnNuevoColaborador" data-bs-toggle="modal" data-bs-target="#modalColaborador">
              <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
              Nuevo colaborador
            </button>
            </div>
        </div>
  
        <div class="card-body px-0 pt-0 pb-2 min-vh-25">
            <div class="table-responsive px-4">
            <table id="datatableColaboradores" class="display">
                <thead>
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nombre</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Cargo</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Descripción</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Teléfono</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Fotografía</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Estado</th>
                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Opciones</th>
                </tr>
                </thead>
  
                <!--<tbody>
                </tbody>-->
  
            </table>
            </div>
        </div>
        </div>
    </div>
  </div> 
</div>

<!-- ========================================================================== -->

<!-- MODAL PARA CREAR NUEVO SLIDER -->
<div class="modal fade" id="modalColaborador" data-bs-backdrop="static" tabindex="-1" aria-labelledby="modalColaboradorLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <h1 class="modal-title fs-5 text-white"><i class="fa fa-user"></i> <span id="modalColaboradorLabel"></span></h1>
      </div>
      <div class="modal-body">
        <span class="text-secondary text-xxs">Los campos con <span class="text-danger">*</span> son obligatorios.</span>
        <form action="" method="post" class="needs-validation" id="formColaborador" enctype="multipart/form-data" novalidate>
          <input type="hidden" name="idColaborador" id="idColaborador">

          <div class="mb-3 row">
            <div class="col-md-6 my-2">
              <label for="nombreColaborador" class="form-label">Nombre <span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Ingrese el nombre del colaborador" id="nombreColaborador" name="nombreColaborador" minlength="5" maxlength="20" required>
              <div class="invalid-feedback">El nombre es requerido.</div>
            </div>

            <div class="col-md-6 my-2">
              <label for="cargoColaborador" class="form-label">Cargo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Ingrese el cargo" id="cargoColaborador" name="cargoColaborador" minlength="5" maxlength="50" required>
              <div class="invalid-feedback">El cargo del colaborador es requerido.</div>
            </div>

            <div class="col-md-6 my-2">
              <div class="form-floating">
                <textarea class="form-control" placeholder="Ingrese una descripción" id="descripcionColaborador" name="descripcionColaborador" style="height: 100px" minlength="5" required></textarea>
                <label for="descripcionColaborador">Ingrese la descripción <span class="text-danger">*</span></label>
                <div class="invalid-feedback">La descripción para el colaborador es requerida.</div>
              </div>
            </div>
  
            <div class="col-md-6 my-2">
              <label for="telefonoColaborador" class="form-label">Teléfono</label>
              <input type="text" class="form-control" placeholder="Ingrese el cargo" id="telefonoColaborador" name="telefonoColaborador"  maxlength="15">
            </div>
  
            <div class="col-md-6 my-2">
              <label for="imgPerfilColaborador" class="form-label">Foto de perfil <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="file" class="form-control" id="imgPerfilColaborador" name="imgPerfilColaborador" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
              </div>
              <img id="imgPreviaColaborador" width="200px" src="" alt="" class="py-2 px-2">
              <div class="invalid-feedback">Debe cargar una imagen del colaborador.</div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

