<div class="container">
  <div class="row">
    <div class="col-12">
        <div class="card mb-4">
        <div class="card-header pb-0 d-flex justify-content-between">
            <h6>Conócenos</h6>
            <div class="d-flex">
  
            <button type="button" class="btn btn-primary" id="btnNuevoSlider" data-bs-toggle="modal" data-bs-target="#modalSlider">
              <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
              Nuevo Slider
            </button>
            </div>
        </div>
  
        <div class="card-body px-0 pt-0 pb-2 min-vh-25">
            <div class="table-responsive px-4">
              <table id="datatableUsuarios" class="table align-items-center mb-0 display">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Frase principal</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Frase superior</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Frase inferior</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Imagen de fondo</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Estado</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Opciones</th>
                    </tr>
                  </thead>
    
                  <!--<tbody>
                  </tbody>-->
    
              </table>
            </div>
        </div>
        </div>
    </div>
  </div> 
  
  <!-- FRASE DINÁMICA -->
  <div class="row">
    <?php 
        $frase_dinamica = ControladorConocenos::ctrMostrarFraseDinamica(null, null);
        $frases =  json_decode($frase_dinamica["frases_dinamicas"], true);
      ?>
    <div class="col-12">
      <div class="card mb-4">
        <div class="card-header pb-0 d-flex justify-content-between">
          <h6>Frase dinámica 
            <?php if($frase_dinamica["activo"] == "1"){
              echo '<span class="badge bg-success">Activo</span>';
              $activo = "checked";
            } else{
              echo '<span class="badge bg-dark">Inactivo</span>';
              $activo = "";
            } ?>
          </h6>
          <i class="fa fa-pencil-square-o cursor-pointer fs-4" data-id="<?php echo $frase_dinamica["id"]; ?>" id="btnContenidoDinamico" data-bs-toggle="modal" data-bs-target="#modalContenidoDinamico" aria-hidden="true"></i>
        </div>
  
        <div class="card-body pt-0 pb-2 section-contenido-dinamico">
          <div class="row">
            <div class="col-md-6">
              <p class="text-center titulo-contenido-dinamico"><i class="fa fa-text-width" aria-hidden="true"></i> Contenido estático</p>
              <p class="text-center"><?php echo htmlspecialchars($frase_dinamica["frase_estatica"]); ?></p>
            </div>
            <div class="col-md-6">
              <p class="text-center titulo-contenido-dinamico"><i class="fa fa-list-alt" aria-hidden="true"></i> Contenido dinámico</p>
              <div class="frases">
  
              <?php 
                if (is_array($frases)) {
                    foreach ($frases as $frase) {
                        echo '<span class="badge bg-primary my-1">'. htmlspecialchars($frase) .'</span> ';
                    }
                }
              ?>
                <!-- <span class="badge bg-primary my-1">Adorar</span>
                <span class="badge bg-primary my-1">Servir</span>
                <span class="badge bg-primary my-1">Vivir para su gloria</span>
                <span class="badge bg-primary my-1">Predicar la palabra de Dios</span> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- ========================================================================== -->
  
  <!-- MODAL PARA CREAR NUEVO SLIDER -->
  <div class="modal fade" id="modalSlider" data-bs-backdrop="static" tabindex="-1" aria-labelledby="modalSliderLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
          <h1 class="modal-title fs-5 text-white"><i class="fa fa-copy"></i> <span id="modalSliderLabel"></span></h1>
        </div>
        <div class="modal-body">
          <span class="text-secondary text-xxs">Los campos con <span class="text-danger">*</span> son obligatorios.</span>
          <form action="" method="post" class="needs-validation" id="formSlider" enctype="multipart/form-data" novalidate>
            <input type="hidden" name="idSlider" id="idSlider">
  
            <div class="mb-3 row">
              <div class="col-md-6">
                <label for="f_principal" class="form-label">Frase principal <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Ingrese una frase principal" id="f_principal" name="f_principal" minlength="5" maxlength="20" required>
                <div class="invalid-feedback">La frase principal es requerida.</div>
              </div>
  
              <div class="col-md-6">
                <label for="f_superior" class="form-label">Frase superior <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Ingrese la frase superior" id="f_superior" name="f_superior" minlength="5" maxlength="50" required>
                <div class="invalid-feedback">La frase superior es requerida.</div>
              </div>
            </div>
  
            <div class="mb-3 row">
              <div class="col-md-6">
                <label for="f_inferior" class="form-label">Frase inferior <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Ingrese la frase inferior" id="f_inferior" name="f_inferior" minlength="5" maxlength="5" required>
                <div class="invalid-feedback">La frase inferior es requerida.</div>
              </div>
  
              <div class="col-md-6">
                <label for="img_fondo" class="form-label">Imagen de fondo <span class="text-danger">*</span></label>
                <div class="input-group">
                  <input type="file" class="form-control" id="imgSlider" name="imgSlider" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                </div>
                <img id="imgPreviaSlider" width="200px" src="" alt="" class="py-2 px-2">
                <div class="invalid-feedback">Debe cargar una imagen de fondo.</div>
              </div>
            </div>
  
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </form>
  
        </div>
      </div>
    </div>
  </div>
  
  <!-- MODAL PARA FRASE DINÁMICA -->
  <div class="modal fade" id="modalContenidoDinamico" data-bs-backdrop="static" tabindex="-1" aria-labelledby="modalContenidoDinamicoLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
          <h1 class="modal-title fs-5 text-white" id="modalContenidoDinamicoLabel"><i class="fa fa-copy"></i> Contenido dinámico del slider</h1>
        </div>
        <div class="modal-body">
          <span class="text-secondary text-xxs">Los campos con <span class="text-danger">*</span> son obligatorios.</span>
          <form action="" method="post" class="needs-validation" id="formContenidoDinamico" novalidate>
            <input type="hidden" name="idFrase" id="idFrase">
  
            <div class="col-md-6">
                <label for="estado_frase" class="form-label">Inactiva / Activa <span class="text-danger">*</span></label>
                <div class="form-check form-switch">
                  <input class="form-check-input estado_frase" <?php echo $activo; ?> id="estado_frase" name="estado_frase" type="checkbox">
                  <label class="form-check-label"></label>
                </div>
              </div>
            <div class="mb-3 row">
              <div class="col-md-6">
                <label for="frase_estatica" class="form-label">Frase estática <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Ingrese una frase principal" id="frase_estatica" name="frase_estatica" minlength="5" maxlength="25" required>
                <div class="invalid-feedback">La frase estática es requerida.</div>
              </div>
  
              <div class="col-md-6">
                <label for="frase_dinamica" class="form-label">Frases dinámicas <span class="text-danger">*</span></label>
                <div class="input-group mb-2">
                  <input type="text" class="form-control" placeholder="Ingrese una palabra o frase" aria-describedby="button-addon2" id="frase_dinamica" name="frase_dinamica" minlength="5" maxlength="50">
                  <button type="button" class="btn btn-primary mb-0" id="btnAgregarFrase">Agregar</button>
                </div>
                <ul id="listaFrases" class="list-group mb-2"></ul>
                <!-- Input oculto donde se guardará el JSON -->
                <input type="hidden" name="frases_json" id="frases_json" required>
                <div class="invalid-feedback">Debe agregar al menos una frase o palabra.</div>
              </div>
  
            </div>
  
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </form>
  
        </div>
      </div>
    </div>
  </div>
</div>
