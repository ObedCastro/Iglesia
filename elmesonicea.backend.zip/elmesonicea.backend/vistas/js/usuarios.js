/* CAMBIAR FOTO DE PERFIL DE USUARIO */
$("#cargarImagenUsuario").on("submit", function(e){
    e.preventDefault();

    var formData = new FormData(this);

    $.ajax({
        url: localhost + 'ajax/usuarios.ajax.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje,
                icon: respuesta.icono,
                showConfirmButton: false,
                timer: 1500
              }).then(() => {
                window.location.href = window.location.href;
              });
        },
        error: function(respuesta) {
            console.log(respuesta);
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje,
                icon: respuesta.icono,
                showConfirmButton: false,
                timer: 1500
            });
        }
    });
})

/* CAMBIAR CONTRASEÑA DE USUARIO */
$("#formCambioPasswordUsuario").on("submit", function(e){
    e.preventDefault();

    var passwords = $("#formCambioPasswordUsuario").serialize();

    var anteriorPassword = $("#formCambioPasswordUsuario #anteriorPassword").val();
    var nuevaPassword = $("#formCambioPasswordUsuario #nuevaPassword").val();
    var repetirPassword = $("#formCambioPasswordUsuario #repetirPassword").val();

    if(anteriorPassword == "" || nuevaPassword == "" || repetirPassword == ""){
        $(".mensajeError").text("Por favor complete todos los campos");
    }else if(nuevaPassword != repetirPassword){
        $(".mensajeError").text("Las contraseñas no coinciden");

        $("#nuevaPassword").on("input", function(){
            $(".mensajeError").text("");
        })
    }else{
        $.ajax({
            url: localhost + 'ajax/usuarios.ajax.php',
            method: "POST",
            dataType: "json",
            data: passwords,
            success: function(respuesta){
                console.log(respuesta);
                if(respuesta.error){
                    $(".mensajeError").text(respuesta.error);

                    $("#anteriorPassword").on("input", function(){
                        $(".mensajeError").text("");
                    })
                } else{
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: "Exito",
                        html: respuesta.mensaje + "<br><span class='badge bg-info text-xs'>Debe loguearse nuevamente, utilizando su nueva contraseña.</span>",
                        showConfirmButton: false,
                        timer: 3000
                      });
    
                      setTimeout(() => {
                        window.location.replace("salir");
                      }, 3000)
                }

            }
        })
    }
    
});