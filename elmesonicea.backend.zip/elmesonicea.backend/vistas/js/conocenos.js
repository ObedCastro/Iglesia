/* ========================================================================== */
/* SLIDERS */
/* ========================================================================== */

/* RESETEAR MODAL ANTES DE UN NUEVO REGISTRO */
function limpiarModal(label, titulo, idElemento, formulario){
    $(`#${label}`).html(titulo);
    $(`#${idElemento}`).val("");
    $(`#${formulario}`)[0].reset();
}

$("#btnNuevoSlider").on("click", function(){
    limpiarModal("modalSliderLabel", " Agregar nuevo slider", "idSlider", "formSlider");
    $('#imgPreviaSlider').attr('src', '');
});

$("#btnNuevaDeclaracion").on("click", function(){
    limpiarModal("modalDeclaracionLabel", " Agregar nueva declaración de fe", "idDeclaracion", "formDeclaracion");
});

$("#btnNuevaNuestrosValores").on("click", function(){
    limpiarModal("modalValoresPilaresLabel", " Agregar item a Nuestros Valores", "idVP", "formValoresPilares");
    $("#tipoVP").val("valores");
});

$("#btnNuevaNuestrosPilares").on("click", function(){
    limpiarModal("modalValoresPilaresLabel", " Agregar item a Nuestros Pilares", "idVP", "formValoresPilares");
    $("#tipoVP").val("pilares");
});

$("#btnNuevoColaborador").on("click", function(){
    limpiarModal("modalColaboradorLabel", " Agregar nuevo colaborador", "idColaborador", "formColaborador");
});

/* $("#btnEditarSlider").on("click", function(){
    limpiarModal("Agregar nuevo slider", "idSlider", "formSlider");
}); */

/* NUEVO SLIDER Y EDITAR SLIDER */
$("#formSlider").on("submit", function(e) {
    e.preventDefault();

    let idSlider = $(this).attr("idEditar");

    let datos = new FormData(this);

    if (idSlider !== undefined) {
        datos.append("id", idSlider);
    }

    datos.append("accion", "guardarSlider");

    $.ajax({
        url: "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: true
            });

            $("#modalSlider").modal("hide");
            tabla.ajax.reload(null, false);
        }
    });
});


/* ELIMINAR SLIDER */
$("#datatableUsuarios").on("click", ".btnEliminarSlider", function(){
    Swal.fire({
        title: "Eliminar slider",
        text: "¿Está seguro que desea eliminar este slider?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {

            var idSlider = $(this).attr("idEliminar");

            var datos = new FormData();
            datos.append("idSlider", idSlider);
            datos.append("accion", "eliminarSlider");

            $.ajax({
                url: localhost + "ajax/conocenos.ajax.php",
                method: "POST",
                data: datos,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta){
                    Swal.fire({
                        title: respuesta.titulo,
                        text: respuesta.mensaje,
                        icon: respuesta.icono,
                        showConfirmButton: true
                      });

                      tabla.ajax.reload(null, false);
                }
            })
        }
    });
});

/* ACTIVAR O DESACTIVAR SLIDER */
$(document).on("click", ".btnEstadoCheck", function(e) {
    /* var idSlider = $(this).attr("idEstado"); */
    var idSlider = $(this).data("id");
    var nuevoEstado = $(this).is(":checked") ? 1 : 0;

    var datos = new FormData();
    datos.append("idSlider", idSlider);
    datos.append("accion", "estadoSlider");
    datos.append("nuevoEstado", nuevoEstado);

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje,
                icon: respuesta.icono,
                showConfirmButton: true
            });

            tabla.ajax.reload(null, false);
        }
    })
});

/* TRAER INFORMACIÓN PARA EDITAR SLIDER */
$(document).on("click", ".btnEditarSlider", function(e) {
    e.preventDefault();
    limpiarModal("modalSliderLabel", "Modificar información de este slider", "idSlider", "formSlider");

    let idSlider = $(this).attr("idEditar");
    
    let datos = new FormData();
    datos.append("idSlider", idSlider);
    datos.append("accion", "traerSlider");

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idSlider").val(respuesta["id"]);
            $("#f_principal").val(respuesta["f_principal"]);
            $("#f_superior").val(respuesta["f_superior"]);
            $("#f_inferior").val(respuesta["f_inferior"]);
            $("#imgPreviaSlider").attr('src', localhost+'vistas/assets/img/sliders/'+respuesta["img_fondo"]);
        }
    });
});

$('#imgSlider').on('change', function () {
  let archivo = this.files[0];
  if (!archivo) return;

  let reader = new FileReader();

  reader.onload = function (e) {
    $('#imgPreviaSlider').attr('src', e.target.result);
  };

  reader.readAsDataURL(archivo);
});


/* ========================================================================== */
/* FRASES DINÁMICAS FORMULARIO */
/* ========================================================================== */

let frases = [];

$('#btnAgregarFrase').click(function () {
  let texto = $('#frase_dinamica').val().trim();

  if (texto === '') return;

  // Evitar duplicados
  if (frases.includes(texto)) {
    alert('Esta frase ya fue agregada.');
    return;
  }

  frases.push(texto);
  actualizarListaFrases();
  actualizarJSONFrases();

  $('#frase_dinamica').val('').focus();
});

function actualizarListaFrases() {
  $('#listaFrases').empty();

  frases.forEach((f, i) => {
    $('#listaFrases').append(`
      <li class="list-group-item d-flex justify-content-between align-items-center">
        ${f}
        <button type="button" class="btn btn-sm btn-danger" onclick="eliminarFrase(${i})">X</button>
      </li>
    `);
  });
}

function eliminarFrase(index) {
  frases.splice(index, 1);
  actualizarListaFrases();
  actualizarJSONFrases();
}

function actualizarJSONFrases() {
  $('#frases_json').val(JSON.stringify(frases));
}

/* MOSTRAR INFO DEL CONTENIDO DINÁMICO */
$("#btnContenidoDinamico").click(function(e){
    e.preventDefault();

    var idFraseDinamica = $(this).data("id");
    
    let datos = new FormData();
    datos.append("accion", "traerFraseDinamica");
    datos.append("idFraseDinamica", idFraseDinamica);

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idFrase").val(respuesta["id"]);
            $("#frase_estatica").val(respuesta["frase_estatica"]);
            $("#frases_json").val(respuesta["frases_dinamicas"]);
        }
    });
});

/* MODIFICAR LAS FRASES DINÁMICAS */
$("#formContenidoDinamico").on("submit", function(e) {
    e.preventDefault();

    let idFrase =  $("#idFrase").val();
    let frase_estatica = $("#frase_estatica").val();
    let frase_dinamica = $("#frases_json").val();
    let estadoFrase = "1";

    if ($("#estado_frase").is(':checked')) {
        estadoFrase = "1";
    } else {
        estadoFrase = "0";
    }

    var datos = new FormData();
    datos.append("accion", "modificarFraseDinamica");
    datos.append("idFrase", idFrase);
    datos.append("frase_estatica", frase_estatica);
    datos.append("frase_dinamica", frase_dinamica);
    datos.append("estadoFrase", estadoFrase);

    $.ajax({
        url: "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {

            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: true
            }).then(() => {
                location.reload();
            });

            $("#modalContenidoDinamico").modal("hide");
        }
    });
});


/* ========================================================================== */
/* DECLARACIÓN DE FE*/
/* ========================================================================== */

/* EDITAR O AGREGAR DECLARACIÓN DE FE */
$("#formDeclaracion").on("submit", function(e) {
    e.preventDefault();

    let datos = new FormData(this);

    datos.append("accion", "guardarDeclaracion");

    $.ajax({
        url: "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: true
            });

            $("#modalDeclaracionFe").modal("hide");
            tablaDeclaraciones.ajax.reload(null, false);
        }
    });
});

/* TRAER INFORMACIÓN PARA EDITAR DECLARACIÓN DE FE */
$(document).on("click", ".btnEditarDeclaracion", function(e) {
    e.preventDefault();
    limpiarModal("modalDeclaracionLabel", " Modificar esta declaración de fe", "idDeclaracion", "formDeclaracion");

    let idDeclaracion = $(this).attr("idEditarDeclaracion");
    
    let datos = new FormData();
    datos.append("idDeclaracion", idDeclaracion);
    datos.append("accion", "traerDeclaracion");

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idDeclaracion").val(respuesta["id"]);
            $("#numero_declaracion").val(respuesta["numero"]);
            $("#tituloDeclaracion").val(respuesta["titulo"]);
            $("#descripcionDeclaracion").val(respuesta["descripcion"]);
            $("#versiculoDeclaracion").val(respuesta["versiculo"]);
        }
    });
});

/* ACTIVAR O DESACTIVAR DECLARACIÓN DE FE */
$(document).on("click", ".btnEstadoDeclaracion", function(e) {
    /* var idSlider = $(this).attr("idEstado"); */
    var idDeclaracion = $(this).data("id");
    var nuevoEstado = $(this).is(":checked") ? 1 : 0;

    var datos = new FormData();
    datos.append("idDeclaracion", idDeclaracion);
    datos.append("accion", "estadoDeclaracion");
    datos.append("nuevoEstado", nuevoEstado);

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje,
                icon: respuesta.icono,
                showConfirmButton: true
            });

            tabla.ajax.reload();
        }
    })
});

/* ELIMINAR DECLARACIÓN DE FE */
$("#datatableDeclaracion").on("click", ".btnEliminarDeclaracion", function(){
    Swal.fire({
        title: "Eliminar declaración de fe",
        text: "¿Está seguro que desea eliminar esta declaración de fe?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {

            var idDeclaracion = $(this).attr("idEliminarDeclaracion");

            var datos = new FormData();
            datos.append("idDeclaracion", idDeclaracion);
            datos.append("accion", "eliminarDeclaracion");

            $.ajax({
                url: localhost + "ajax/conocenos.ajax.php",
                method: "POST",
                data: datos,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta){
                    Swal.fire({
                        title: respuesta.titulo,
                        text: respuesta.mensaje,
                        icon: respuesta.icono,
                        showConfirmButton: true
                      });

                      tablaDeclaraciones.ajax.reload(null, false);
                }
            })
        }
    });
});


/* ========================================================================== */
/* NUESTROS VALORES Y NUESTROS PILARES*/
/* ========================================================================== */

$("#formValoresPilares").on("submit", function(e) {
    e.preventDefault();

    let datos = new FormData(this);

    datos.append("accion", "guardarValoresPilares");

    $.ajax({
        url: "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: true
            });

            $("#modalValoresPilares").modal("hide");

            tablaNuestrosValores.ajax.reload(null, false);
            tablaNuestrosPilares.ajax.reload(null, false);
        }
    });
});

/* TRAER INFORMACIÓN PARA EDITAR NUESTROS VALORES Y NUESTROS PILARES */
$(document).on("click", ".btnEditarValores", function(e) {
    e.preventDefault();
    limpiarModal("modalValoresPilaresLabel", " Modificar información de Nuestros Valores", "idVP", "formValoresPilares");
    $("#tipoVP").val("valores");

    let tipoVP = $("#tipoVP").val();
    let idVP = $(this).attr("idEditarValores");

    let datos = new FormData();
    datos.append("tipoVP", tipoVP);
    datos.append("idVP", idVP);
    datos.append("accion", "traerValoresPilares");

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idVP").val(respuesta["id"]);
            $("#tituloVP").val(respuesta["titulo"]);
            $("#descripcionVP").val(respuesta["descripcion"]);
        }
    });
});

$(document).on("click", ".btnEditarPilares", function(e) {
    e.preventDefault();
    limpiarModal("modalValoresPilaresLabel", " Modificar información de Nuestros Pilares", "idVP", "formValoresPilares");
    $("#tipoVP").val("pilares");

    let tipoVP = $("#tipoVP").val();
    let idVP = $(this).attr("idEditarPilares");

    let datos = new FormData();
    datos.append("tipoVP", tipoVP);
    datos.append("idVP", idVP);
    datos.append("accion", "traerValoresPilares");

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idVP").val(respuesta["id"]);
            $("#tituloVP").val(respuesta["titulo"]);
            $("#descripcionVP").val(respuesta["descripcion"]);
        }
    });
});

/* ACTIVAR O DESACTIVAR VALORES O PILARES */
$(document).on("click", ".btnEstadoValores, .btnEstadoPilares", function(e) {
    let clases = $(this).attr('class');
    var arrayClases = clases.split(" ");
    var ultimaClase = arrayClases[arrayClases.length - 1];
    var tipoVP = ultimaClase.match(/[A-Z][a-z]*$/)[0].toLowerCase();

    var idVP = $(this).data("id");
    var nuevoEstado = $(this).is(":checked") ? 1 : 0;

    var datos = new FormData();
    datos.append("tipoVP", tipoVP);
    datos.append("idVP", idVP);
    datos.append("accion", "estadoValoresPilares");
    datos.append("nuevoEstado", nuevoEstado);

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje,
                icon: respuesta.icono,
                showConfirmButton: true
            });

            tablaNuestrosValores.ajax.reload(null, false);
            tablaNuestrosPilares.ajax.reload(null, false);
        }
    })
});

/* ELIMINAR ITEM DE VALORES O PILARES*/
$(document).on("click", ".btnEliminarValores, .btnEliminarPilares", function() {

    Swal.fire({
        title: "Eliminar este item",
        text: "¿Está seguro que desea eliminar esta declaración de fe?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {

                var clases = this.className.split(" ");
                var claseEliminar = clases.find(c => c.startsWith("btnEliminar"));
                var tipoVP = claseEliminar.replace("btnEliminar", "").toLowerCase();

                var idVP = $(this).attr("idEliminarValoresPilares");

                var datos = new FormData();
                datos.append("tipoVP", tipoVP);
                datos.append("idVP", idVP);
                datos.append("accion", "eliminarValoresPilares");

                $.ajax({
                    url: localhost + "ajax/conocenos.ajax.php",
                    method: "POST",
                    data: datos,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: "json",
                    success: function(respuesta){
                        Swal.fire({
                            title: respuesta.titulo,
                            text: respuesta.mensaje,
                            icon: respuesta.icono,
                            showConfirmButton: true
                        });

                        tablaNuestrosValores.ajax.reload(null, false);
                        tablaNuestrosPilares.ajax.reload(null, false);
                    }
                })
            }
    });
});


/* ========================================================================== */
/* COLABORADORES */
/* ========================================================================== */

/* EDITAR O AGREGAR COLABORADORES */
$("#formColaborador").on("submit", function(e) {
    e.preventDefault();

    let datos = new FormData(this);

    datos.append("accion", "guardarColaborador");

    $.ajax({
        url: "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: true
            });

            $("#modalColaborador").modal("hide");
            tablaColaboradores.ajax.reload(null, false);
        }
    });
});

/* TRAER INFORMACIÓN PARA EDITAR DECLARACIÓN DE FE */
$(document).on("click", ".btnEditarDeclaracion", function(e) {
    e.preventDefault();
    limpiarModal("modalDeclaracionLabel", " Modificar esta declaración de fe", "idDeclaracion", "formDeclaracion");

    let idDeclaracion = $(this).attr("idEditarDeclaracion");
    
    let datos = new FormData();
    datos.append("idDeclaracion", idDeclaracion);
    datos.append("accion", "traerDeclaracion");

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idDeclaracion").val(respuesta["id"]);
            $("#numero_declaracion").val(respuesta["numero"]);
            $("#tituloDeclaracion").val(respuesta["titulo"]);
            $("#descripcionDeclaracion").val(respuesta["descripcion"]);
            $("#versiculoDeclaracion").val(respuesta["versiculo"]);
        }
    });
});

/* ACTIVAR O DESACTIVAR DECLARACIÓN DE FE */
$(document).on("click", ".btnEstadoDeclaracion", function(e) {
    /* var idSlider = $(this).attr("idEstado"); */
    var idDeclaracion = $(this).data("id");
    var nuevoEstado = $(this).is(":checked") ? 1 : 0;

    var datos = new FormData();
    datos.append("idDeclaracion", idDeclaracion);
    datos.append("accion", "estadoDeclaracion");
    datos.append("nuevoEstado", nuevoEstado);

    $.ajax({
        url: localhost + "ajax/conocenos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje,
                icon: respuesta.icono,
                showConfirmButton: true
            });

            tabla.ajax.reload();
        }
    })
});

/* ELIMINAR DECLARACIÓN DE FE */
$("#datatableDeclaracion").on("click", ".btnEliminarDeclaracion", function(){
    Swal.fire({
        title: "Eliminar declaración de fe",
        text: "¿Está seguro que desea eliminar esta declaración de fe?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {

            var idDeclaracion = $(this).attr("idEliminarDeclaracion");

            var datos = new FormData();
            datos.append("idDeclaracion", idDeclaracion);
            datos.append("accion", "eliminarDeclaracion");

            $.ajax({
                url: localhost + "ajax/conocenos.ajax.php",
                method: "POST",
                data: datos,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta){
                    Swal.fire({
                        title: respuesta.titulo,
                        text: respuesta.mensaje,
                        icon: respuesta.icono,
                        showConfirmButton: true
                      });

                      tablaDeclaraciones.ajax.reload(null, false);
                }
            })
        }
    });
});