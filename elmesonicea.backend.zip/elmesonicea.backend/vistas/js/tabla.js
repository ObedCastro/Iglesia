/* TABLA DE SLIDERS */
let tabla = new DataTable('#datatableUsuarios', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=sliders',     
    ordering: false,
    columns: [
        { 
            data: 'f_principal',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'f_superior',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'f_inferior',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'img_fondo',
            render: function (data, type) {
                return '<span class="text-xs"><img width="100px" src="'+localhost+'vistas/assets/img/sliders/'+data+'"></span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoCheck" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarSlider badge text-secondary" idEditar="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalSlider">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarSlider badge" idEliminar="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        { data: 'fecha_creacion', visible: false }
    ],
    order: [[6, 'asc']],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});

/* TABLA DE DECLARACIONES DE FE */
let tablaDeclaraciones = new DataTable('#datatableDeclaracion', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=declaraciones',     
    ordering: false,
    columns: [
        { 
            data: 'numero',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'titulo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'descripcion',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'versiculo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoDeclaracion" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarDeclaracion badge text-secondary" idEditarDeclaracion="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalDeclaracionFe">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarDeclaracion badge" idEliminarDeclaracion="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        { data: 'fecha_creacion', visible: false }
    ],
    order: [[6, 'asc']],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});


/* TABLA DE NUESTROS VALORES */
let tablaNuestrosValores = new DataTable('#datatableNuestrosValores', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=valores',     
    ordering: true,
    deferRender: true,
    retrieve: true,
    processing: true,
    lengthMenu: [
        [3, 5],
        [3, 5]
    ],
    columns: [
        { 
            data: 'titulo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'descripcion',
            render: function (data, type) {
                return '<span class="descripcion-VP">'+data+'</span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoValores" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarValores badge text-secondary" idEditarValores="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalValoresPilares">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarValores badge" idEliminarValoresPilares="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        { data: 'fecha_registro', visible: false }
    ],
    order: [[4, 'asc']],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});

/* TABLA NUESTROS PILARES */
let tablaNuestrosPilares = new DataTable('#datatableNuestrosPilares', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=pilares',     
    ordering: true,
    deferRender: true,
    retrieve: true,
    processing: true,
    lengthMenu: [
        [3, 5],
        [3, 5]
    ],
    columns: [
        { 
            data: 'titulo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'descripcion',
            render: function (data, type) {
                return '<span class="descripcion-VP">'+data+'</span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoPilares" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarPilares badge text-secondary" idEditarPilares="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalValoresPilares">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarPilares badge" idEliminarValoresPilares="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        { data: 'fecha_registro', visible: false }
        
    ],
    order: [[4, 'asc']],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});

/* TABLA DE COLABORADORES */
let tablaColaboradores = new DataTable('#datatableColaboradores', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=colaboradores',     
    ordering: true,
    deferRender: true,
    retrieve: true,
    processing: true,
    lengthMenu: [
        [3, 5],
        [3, 5]
    ],
    columns: [
        { 
            data: 'nombre',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'cargo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'descripcion',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'telefono',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'foto_perfil',
            render: function (data, type) {
                return '<span class="text-xs"><img style="border-radius: 50%;" width="70px" src="'+localhost+'vistas/assets/img/colaboradores/'+data+'"></span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoColaboradores" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarColaborador badge text-secondary" idEditarColaborador="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalColaborador">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarColaboradores badge" idEliminarColaboradores="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        { data: 'fecha_registro', visible: false }
        
    ],
    order: [[4, 'asc']],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});

