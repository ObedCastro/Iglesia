/* TABLA DE SLIDERS */
let tabla = new DataTable('#datatableUsuarios', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=sliders',     
    ordering: false,
    columns: [
        { 
            data: 'f_principal',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'f_superior',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'f_inferior',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'img_fondo',
            render: function (data, type) {
                return '<span class="text-xs"><img width="100px" src="'+localhost+'vistas/assets/img/sliders/'+data+'"></span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoCheck" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarSlider badge text-secondary" idEditar="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalSlider">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarSlider badge" idEliminar="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        
    ],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});

/* TABLA DE DECLARACIONES DE FE */
let tablaDclaraciones = new DataTable('#datatableDeclaracion', {
    ajax: 'ajax/tablas.ajax.php?tipoTabla=declaraciones',     
    ordering: false,
    columns: [
        { 
            data: 'numero',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'titulo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'descripcion',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'versiculo',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'activo',
            render: function (data, type, row) {
                var activo = (data == "1") ? "checked" : "";
                return `<div class="form-check form-switch"><input class="form-check-input btnEstadoDeclaracion" data-id="${row.id}"  type="checkbox" ${activo}><label class="form-check-label"></label></div>`;
            }
        },
        { 
            data: 'id',
            render: function (data, type) {
                return '<div class="btn-group align-top">'+
                            '<button class="btn btn-outline-secondary btnEditarDeclaracion badge text-secondary" idEditarDeclaracion="'+data+'" type="button" data-bs-toggle="modal" data-bs-target="#modalDeclaracionFe">'+
                                '<i class="fa fa-pencil text-secondary"></i>'+
                            '</button>'+
                            '<button class="btn btn-outline-secondary btnEliminarDeclaracion badge" idEliminarDeclaracion="'+data+'" type="button">'+
                                '<i class="fa fa-trash text-danger"></i>'+
                            '</button>'+
                        '</div>';
            }
        },
        
    ],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});