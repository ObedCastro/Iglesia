/* AGREGA IMÁGENES AL FORMULARIO DEL EVENTO */
$("#btnAgregarImagen").on("click", function () {

    let html = `
        <div class="row imagen-item mb-3">
            <div class="col-md-4">
                <input type="file" name="imagenes[]" class="form-control" accept="image/jpeg,image/png" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="titulosImagen[]" class="form-control" placeholder="Título imagen" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="descripcionesImagen[]" class="form-control" placeholder="Descripción imagen" required>
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-danger btnEliminar">✖</button>
            </div>
        </div>
    `;

    $("#contenedorImagenes").append(html);
});

$(document).on("click", ".btnEliminar", function () {
    $(this).closest(".imagen-item").remove();
});

/* REGISTRAR UN NUEVO EVENTO */
$("#formEvento").on("submit", function (e) {
    e.preventDefault();

    let datos = new FormData(this);
    datos.append("accion", "guardarEvento");

    $.ajax({
        url: "ajax/eventos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (respuesta) {

            Swal.fire({
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje
            });

            if (respuesta.icono === "success") {
                $("#formEvento")[0].reset();
                $("#contenedorImagenes").html("");
            }
        }
    });
});

