


//LIMPIAR CAMPOS DE CAMBIO DE CONTRASEÑA
const myOffcanvas = document.getElementById('offcanvasScrolling')
myOffcanvas.addEventListener('hidden.bs.offcanvas', event => {
  $("#anteriorPassword").val("");
    $("#nuevaPassword").val("");
    $("#repetirPassword").val("");
    $(".mensajeError").text("");
    $("#accordionPassword .collapse").collapse("hide");
});


function Copiar(texto) {
    navigator.clipboard.writeText(texto).then(() => {
    });
  }